from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import User, Group
from .models import Device, Channel

admin.site.unregister(User)
admin.site.unregister(Group)

admin.site.site_header = "AdWatch Technical Panel"
admin.site.index_title = "Technical Menu"
admin.site.site_title = "AdWatch Technical Panel"


@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    model = Device
    list_display = ("alias", "name", "group", "status")


@admin.register(Channel)
class ChannelAdmin(admin.ModelAdmin):
    model = Channel
    list_display = ("get_station", "group", "status", "number")

    def get_station(self, obj):
        station = obj.station
        if station:
            if obj.device.group == "FM":
                station += f" ({obj.freq})"

        return station

    get_station.short_description = _("Station")

    def group(self, obj):
        return obj.device.group

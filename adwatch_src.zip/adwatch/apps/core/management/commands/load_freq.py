from django.core.management import BaseCommand
from apps.core.models import Channel, Device
from freq_list import RADIOS


class Command(BaseCommand):
    def handle(self, *args, **kwargs):
        device = Device.objects.get(alias="radcap")
        n = 0
        for radio in RADIOS:
            try:
                channel = Channel.objects.get(device=device, number=n)
                channel.station = radio["station"]
                channel.freq = radio["freq"]
                channel.number = n
                channel.device = device
                channel.save()
                n += 1
            except Channel.DoesNotExist:
                print(f"[***] ERROR. Can't find channel n.{n}")
                break

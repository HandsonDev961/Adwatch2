import re
import subprocess
from django.conf import settings
from .models import Device, Channel


def radcap_init():
    # Set the RadCap device at start
    if settings.STAGE == "development":
        Device.objects.all().delete()
        device = Device()
        device.alias = "Mac"
        device.name = ":"
        device.group = Device.FM
        device.status = Device.CONNECTED
        device.save()

        channel = Channel()
        channel.number = 1
        channel.device = device
        channel.station = "ALONDRA"
        channel.freq = 96.9
        channel.save()
        return

    # Get ALSA device for RadCap
    cmd = "arecord -L|grep -e '^hw:CARD=FMRadcap'"
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    output = p.communicate()[0].decode("utf-8").rstrip()
    radcap_device = output.replace("DEV=", "") + ","  # Comma to add channels

    try:
        device = Device.objects.get(alias="radcap")
    except Device.DoesNotExist:
        device = Device()
    device.alias = "radcap"
    device.name = radcap_device
    device.group = Device.FM
    device.status = Device.CONNECTED
    device.save()

    # Set channels as available at startup
    channels = Channel.objects.filter(device=device)

    # Get radcap frequencies
    radcap = []
    for i in range(5):  # FIXME: range must be 32 on production
        cmd = "radcap -s {}".format(i)
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        output = p.communicate()[0].decode("utf-8").rstrip()
        s = re.search(r"([0-9]+)kHz", output)
        freq = int(s[1]) / 1000
        radcap.append(freq)


    if len(channels):
        for channel in channels:
            channel.status = Channel.AVAILABLE
            channel.freq = radcap[channel.number]
            channel.save(update_fields=["status", "freq"])
        pass
    else:
        # Create RadCap channels if not created
        channel_list = []
        for n in range(5):  # FIXME: range must be 32 on production
            channel = Channel()
            channel.number = n
            channel.device = device
            channel.freq = radcap[n]
            channel_list.append(channel)

        Channel.objects.bulk_create(channel_list)

def usb_init():
    # Get ALSA devices for USB
    if settings.STAGE == "development":
        return

    cmd = "arecord -L|grep -e '^hw:CARD=Device'"
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    output = p.communicate()[0].decode("utf-8").rstrip()

    devices = []
    if "\n" in output:
        # More than one device
        devices = output.split("\n")
    else:
        devices.append(output)

    for device_name in devices:
        usb_device = device_name.replace("DEV=", "") + ","  # Comma to add channels

        alias = "TV %s" % usb_device[8:-2]

        try:
            device = Device.objects.get(alias=alias)
        except Device.DoesNotExist:
            device = Device()
        device.alias = alias
        device.name = usb_device
        device.group = Device.TV
        device.status = Device.CONNECTED
        device.save()

        # Check if channels are created
        try:
            channel = Channel.objects.get(device=device)
            # channel.status = Channel.AVAILABLE
            # channel.save()

        except Channel.DoesNotExist:
            # Create ONE (1) TV channel if not created
            channel = Channel()
            channel.number = 1
            channel.device = device
            channel.save()

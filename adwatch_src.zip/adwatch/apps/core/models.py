import subprocess

from django.conf import settings
from django.db import models
from django.dispatch import receiver
from django.utils.translation import gettext_lazy as _
from django.db.models.signals import post_save


# Create your models here.
class Device(models.Model):
    FM = "FM"
    TV = "TV"
    GROUP_CHOICES = (
        (FM, "FM"),
        (TV, "TV"),
    )

    DISCONNECTED = 0
    CONNECTED = 1

    STATUS_CHOICES = (
        (DISCONNECTED, "DISCONNECTED"),
        (CONNECTED, "CONNECTED"),
    )
    alias = models.CharField(max_length=32, verbose_name=_("Alias"))
    name = models.CharField(max_length=128, verbose_name=_("Device name"))
    group = models.CharField(
        max_length=2, choices=GROUP_CHOICES, verbose_name=_("Group")
    )  # FM / TV
    status = models.IntegerField(
        choices=STATUS_CHOICES, default=CONNECTED, verbose_name=_("Status")
    )

    def __str__(self) -> str:
        return self.alias


class Channel(models.Model):
    DISABLED = -1
    AVAILABLE = 1
    RECORDING = 2

    STATUS_CHOICES = (
        (DISABLED, "DISABLED"),
        (AVAILABLE, "AVAILABLE"),
        (RECORDING, "RECORDING"),
    )
    number = models.IntegerField(verbose_name=_("CH #"))
    device = models.ForeignKey(
        Device, on_delete=models.CASCADE, verbose_name=_("Device")
    )
    station = models.CharField(
        max_length=128, blank=True, null=True, verbose_name=_("Station")
    )
    status = models.IntegerField(
        choices=STATUS_CHOICES, default=AVAILABLE, verbose_name=_("Status")
    )
    # Frequency only used for group FM
    freq = models.FloatField(null=True, verbose_name=_("Frequency"))

    def __str__(self) -> str:
        return f"{self.station}"


@receiver(post_save, sender=Channel)
def channel_post_save(instance: Channel, *args, **kwargs):
    """Update Radcap with new frequency when channel is saved"""
    device = instance.device
    if device.group == Device.FM:
        # Call radcap command and update frequency
        cmd = "radcap -c 1 -s {} -f {:.0f}".format(instance.number, (instance.freq * 1000))

        # print(cmd)
        if settings.STAGE == "development":
            return

        # print(cmd)
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        output = p.communicate()[0].decode("utf-8").rstrip()
        # print(output)


from django.db import models
from django.db.models.signals import post_delete
from django.dispatch import receiver
from django.utils.translation import gettext_lazy as _


# Create your models here.
class Recording(models.Model):
    """Recordings"""

    GROUP_CHOICES = (
        ("FM", "FM"),
        ("TV", "TV"),
    )

    device_alias = models.CharField(max_length=128, verbose_name=_("Device Alias"))
    device_name = models.CharField(max_length=128, verbose_name=_("Device Name"))
    channel_number = models.IntegerField(verbose_name=_("CH #"))
    group = models.CharField(
        max_length=2, choices=GROUP_CHOICES, verbose_name=_("Group")
    )
    station = models.CharField(max_length=128, verbose_name=_("Station"))
    file = models.FileField(upload_to="recording", verbose_name=_("File"))
    ts = models.DateTimeField(auto_now_add=True, verbose_name=_("Date"))

    def __str__(self) -> str:
        return f"{self.station}"


@receiver(post_delete, sender=Recording)
def recording_post_delete(instance, *args, **kwargs):
    """Delete file after delete record"""
    instance.file.delete(save=False)

import time
from django.core.management import BaseCommand
from apps.record.tasks import RecordTask
from apps.core.devices import radcap_init, usb_init


class Command(BaseCommand):
    def handle(self, *args, **kwargs):
        # Init devices
        radcap_init()
        usb_init()

        time.sleep(3)

        # Start recording
        task = RecordTask()
        task.start(cmd=True)

from django.contrib import admin
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from .models import Recording


@admin.register(Recording)
class RecordingAdmin(admin.ModelAdmin):
    model = Recording
    ordering = ["-ts"]
    search_fields = ("station", "group", "device_name", "device_alias")
    list_display = (
        "station",
        "group",
        "ts",
        "display_audio_player",
        "device_alias",
        "device_name",
        "channel_number",
    )
    list_display_links = None
    list_filter = ("group", "ts")
    list_per_page = 10

    def display_audio_player(self, obj):
        """Audio player for django admin"""
        from django.utils.safestring import mark_safe

        audio_url = settings.MEDIA_URL + str(obj.file)
        widget = f"<audio controls><source src='{audio_url}' /></audio>"

        return mark_safe(widget)

    display_audio_player.short_description = _("Recording")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

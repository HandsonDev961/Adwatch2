import ffmpeg
import time
import hashlib
from datetime import datetime
from threading import Thread
from multiprocessing import Process

import django
django.setup()
from django.conf import settings
from apps.core.models import Channel, Device
from apps.record.models import Recording



def generate_filename(channel_name):
    """Generate filename format for recording"""
    # salt = str(channel.pk) + str(time.time())
    # salt = salt.encode("utf-8")
    # salt = hashlib.md5(salt).hexdigest()[:6]

    date = datetime.now().strftime("%Y-%m-%d_%H")

    channel_name = channel_name.replace(" ", "_")
    filename = f"recording/{channel_name}_{date}.mp3"

    return filename


class RecordTask:
    """Record all available channels"""

    threads = []

    def record(self, channel_id):
        # Start recording process
        while True:
            try:
                channel = Channel.objects.get(pk=channel_id)
            except Channel.DoesNotExist:
                # Channel doesn't exist, exit thread
                return

            # FIXME: Only for testing. It should record even without station name
            if not channel.station:
                continue

            print(f"[.] Init record {channel.device} {channel.station}")
            # Wait 1 minute to try again if device is disconnected
            if channel.device.status == Device.DISCONNECTED:
                print("Device [{}] DISCONNECTED".format(channel.device.alias))
                time.sleep(2)
                continue

            if channel.status == Channel.DISABLED:
                print("Channel [{}] DISABLED".format(channel.number))
                time.sleep(2)
                continue

            if channel.status == Channel.AVAILABLE:
                channel.status = Channel.RECORDING
                channel.save(update_fields=["status"])
                # time.sleep(2)
                # continue

            filename = f"{settings.MEDIA_ROOT}/" + generate_filename(channel.station)

            recording = Recording()
            recording.device_alias = channel.device.alias
            recording.device_name = channel.device.name
            recording.channel_number = channel.number
            recording.group = channel.device.group
            recording.station = f"{channel.station}"
            if channel.device.group == "FM":
                recording.station += f" ({channel.freq})"
            recording.file.name = generate_filename(channel.station)
            recording.save()

            # FIXME:
            # DEV: ffmpeg -f avfoundation -i ":0"     (ffmpeg use video:audio device)
            # Production command: ffmpeg -f alsa -i hw:CARD=FMRadcapPCIe,0,$ch_id
            device_path = channel.device.name + str(channel.number)

            # Calculate time to record one file per hour
            minute = datetime.now().minute
            seconds = datetime.now().second
            passed = (60 * minute) + seconds
            record_time = (60 * 60) - passed

            if settings.STAGE == "development":
                (
                    ffmpeg.input(device_path, f="avfoundation", t=record_time)  # 1 hour
                    .output(filename)
                    .global_args("-y")
                    .global_args("-loglevel", "quiet")
                    .run()
                )
            else:
                (
                    ffmpeg.input(device_path, f="alsa", t=record_time)  # 60 minutes
                    .output(filename)
                    .global_args("-y")
                    .global_args("-loglevel", "quiet")
                    .run()
                )


    def start(self, cmd=False):
        # if settings.STAGE == 'development':
        #     print("[-] Recording disabled in development (record/tasks.py)")
        #     return
        print("[+] Starting recording process")
        channels = Channel.objects.filter(status=Channel.AVAILABLE)
        for channel in channels:
            channel_id = channel.pk
            t = Process(target=self.record, args=[channel_id])
            t.start()
            self.threads.append(t)

        if cmd:
            for t in self.threads:
                t.join()

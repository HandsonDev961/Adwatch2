from django.contrib import admin
from django.utils.html import mark_safe

from .models import Jingle, JingleMatch

@admin.register(Jingle)
class JingleAdmin(admin.ModelAdmin):
    model = Jingle
    list_display = ("name", "get_file", "get_duration", "upload_ts", "active")
    list_filter = ("active",)
    search_fields = ("name", "mime")
    ordering = ("-upload_ts",)
    readonly_fields = ("duration", "mime", "fingerprint", "upload_ts")

    # Show audio player in admin
    def get_file(self, obj):
        return mark_safe('<audio controls><source src="{}"></audio>'.format(obj.file.url))
    get_file.short_description = "Audio"

    def get_duration(self, obj):
        return "{:.2f}s".format(obj.duration)
    get_duration.short_description = "Duration"


@admin.register(JingleMatch)
class JingleMatchAdmin(admin.ModelAdmin):
    model = JingleMatch
    list_display = ("jingle", "get_record", "get_station", "match_ts")
    list_filter = ("jingle", "record__station")
    search_fields = ("jingle__name", "record__station__name")
    ordering = ("-match_ts",)

    def get_record(self, obj):
        return mark_safe('<audio controls src="{}"></audio>'.format(
            obj.record.file.url,
        ))
    get_record.short_description = "Audio"

    def get_station(self, obj):
        return obj.record.station
    get_station.short_description = "Station"
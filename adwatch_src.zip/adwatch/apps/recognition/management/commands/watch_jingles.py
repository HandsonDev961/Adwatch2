import os
import time
import tempfile
import multiprocessing as mp
from threading import Thread, Event

import essentia.standard as es
import acoustid as ai

import django

django.setup()
from django.core.management import BaseCommand
from apps.recognition.models import Jingle, JingleMatch
from apps.record.models import Recording
from apps.core.models import Channel
from apps.record.tasks import generate_filename
# from apps.recognition.utils.monitors import get_record_name, get_stream
from django.conf import settings
from django.utils import timezone


class JingleWatch:
    def __init__(self):
        pass

    def invert(self, arr):
        """
        Make a dictionary that with the array elements as keys and
        their positions positions as values.
        """
        map = {}
        for i, a in enumerate(arr):
            map.setdefault(a, []).append(i)
        return map

    def popcnt(self, x):
        """
        Count the number of set bits in the given 32-bit integer.
        """
        popcnt_table_8bit = [
            0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5,
            1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
            1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
            2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7,
            1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, 2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
            2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7,
            2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, 3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7,
            3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, 4, 5, 5, 6, 5, 6, 6, 7, 5, 6, 6, 7, 6, 7, 7, 8,
        ]
        return (popcnt_table_8bit[(x >> 0) & 0xFF] +
                popcnt_table_8bit[(x >> 8) & 0xFF] +
                popcnt_table_8bit[(x >> 16) & 0xFF] +
                popcnt_table_8bit[(x >> 24) & 0xFF])

    def ber(self, fp_full, fp_frag, offset):
        """
        Compare the short snippet against the full track at given offset.
        """
        errors = 0
        count = 0
        for a, b in zip(fp_full[offset:], fp_frag):
            errors += self.popcnt(a ^ b)
            count += 1
        return max(0.0, 1.0 - 2.0 * errors / (32.0 * count))

    def compare_fingerprints(self, fp_full, fp_frag):
        full_20bit = [x & (1 << 20 - 1) for x in fp_full]
        short_20bit = [x & (1 << 20 - 1) for x in fp_frag]

        common = set(full_20bit) & set(short_20bit)

        i_full_20bit = self.invert(full_20bit)
        i_short_20bit = self.invert(short_20bit)

        offsets = {}
        for a in common:
            for i in i_full_20bit[a]:
                for j in i_short_20bit[a]:
                    o = i - j
                    offsets[o] = offsets.get(o, 0) + 1

        matches = []
        for count, offset in sorted([(v, k) for k, v in offsets.items()], reverse=True)[:20]:
            matches.append((self.ber(fp_full, fp_frag, offset), offset))
        matches.sort(reverse=True)

        try:
            score, offset = matches[0]
        except:
            score = 0
            offset = 0

        offset_secs = int(offset * 0.1238) # each fingerprint item represents 0.1238 seconds

        fp_duration = len(fp_frag) * 0.1238 + 2.6476 # there is also a duration offset found empirically

        # print("position %d:%02d with score %f" % (offset_secs / 60, offset_secs % 60, score))
        position = "%d:%02d" % (offset_secs / 60, offset_secs % 60)
        return {"position": position, "score": score}


class Command(BaseCommand):
    def handle(self, *args, **options):
        # Get active stations, connect to their streams and get audio chunks

        threads = []
        pool = mp.Pool(processes=mp.cpu_count() * 2)
        while True:
            channels = Channel.objects.filter(status=Channel.RECORDING)
            for channel in channels:
                # Check if station is already being watched
                if channel.pk in [p[0] for p in threads]:
                    continue
                e = Event()
                t = Thread(target=self.match_jingles, args=(channel, pool, e))
                threads.append((channel.pk, t, e))
                t.start()

            # if any station id is not in threads list, terminate the thread
            for channel_pk, t, e in threads:
                if channel_pk not in [s.pk for s in channels]:
                    e.set()
                    t.join()
                    threads.remove((channel_pk, t, e))

            time.sleep(3)

    def match_jingles(self, channel: Channel, pool: mp.Pool, event: Event):
        """Match jingles with audio chunks"""
        channel_name = channel.station

        print(f"[+][{channel_name}] Watching jingles...")

        while True:
            # finish watching jingles (thread finished)
            if event.is_set():
                print(f"[*] Finish watching jingles {channel_name}")
                break
            print("---------- {} ----------".format(channel_name))
            start = time.time()

            # Create record name in each loop. Name changes with the date and hour
            recording_name = f"{settings.MEDIA_ROOT}/" + generate_filename(channel_name)

            # Get record from db
            try:
                record: Recording = Recording.objects.get(file=generate_filename(channel_name))
            except Recording.DoesNotExist:
                print("Recording does not exist")
                time.sleep(3)
                continue

            # Run jingle_check_matches for each jingle
            jingles = Jingle.objects.filter(active=True)
            jingles_iterable = []
            for jingle in jingles:
                iterable_item = (recording_name, str(jingle.file.path), int(jingle.pk))
                jingles_iterable.append(iterable_item)

            # run jingle_check_matches in parallel
            print("Running jingle_check_matches in parallel")
            result = pool.starmap(jingle_check_matches, jingles_iterable)

            # get the result list and add matches to jingle match
            for r in result:
                if r:
                    # To fix duplicates: check if jingle match already exists in the past minute
                    jingle_match = JingleMatch.objects.filter(
                        jingle_id=r["jingle_id"],
                        record_id=record.pk,
                        match_ts__gte=timezone.now() - timezone.timedelta(minutes=1),
                    )
                    if jingle_match:
                        print("[***] Jingle Match already exists in the past minute")
                        continue

                    jingle_match = JingleMatch.objects.create(
                        jingle_id=r["jingle_id"],
                        record_id=record.pk,
                    )
                    print("---------- Jingle Match ----------")
                    print("Station: {}".format(channel_name))
                    print("Jingle: {}".format(jingle_match.jingle.name))
                    print("Match time: {}".format(jingle_match.match_ts))
                    print("Score: {:.2f}".format(r['result']['score']))
                    print("---------- Jingle Match ----------")
                    time.sleep(5)  # save some resources preventing duplicates

            # end = time.time()
            # print("time execution: {:.2f}s".format(end - start))

            time.sleep(10)


def jingle_check_matches(recording_name: str, jingle_path: str, jingle_id: int):
    chunk_fp = get_last_record_chunk(recording_name)
    audio_live = chunk_fp.name

    result = compare(audio_live, jingle_path)
    if result and result["score"] > 0.65:
        return {
            "jingle_id": jingle_id,
            "result": result,
        }


def get_last_record_chunk(stream: str) -> tempfile.NamedTemporaryFile:
    # temp_f = open("media/tmp/concierto.mp3", "w+b")  # temp file
    # Create temp file with TemporaryFile
    temp_f = tempfile.NamedTemporaryFile("w+b", dir="{}/tmp".format(settings.MEDIA_ROOT))

    # check if stream exists, if not wait until exists
    while not os.path.exists(stream):
        print("waiting for stream...")
        time.sleep(1)

    # read record file and cut the last chunk
    with open(stream, "rb") as f:
        # write to temp file the last 1.5MB of file stream
        f.seek(0, 2)
        last_p = f.tell()
        # print("tell: {}".format(last_p))
        max_bytes = 100 * 1024
        # print("max_bytes: {}".format(max_bytes))
        if last_p < max_bytes:
            max_bytes = last_p

        # print("final max_bytes: {}".format(max_bytes))
        f.seek(max_bytes * -1, 2)
        temp_f.write(f.read(max_bytes))
        # print(f"{stream} -> {temp_f.name}")
    return temp_f


def compare(audio_live, audio_jingle):
    # start = time.time()
    try:
        fs = 44100
        audio = es.MonoLoader(filename=audio_live, sampleRate=fs)()
        duration_audio = len(audio) / 44100

        jingle = es.MonoLoader(filename=audio_jingle, sampleRate=fs)()
        duration_jingle = len(jingle) / 44100
    except:  # noqa
        # Sometimes the audio_live file is empty
        return None

    audio_fingerprint = es.Chromaprinter()(audio)
    audio_fingerprint = audio_fingerprint.encode("utf-8")
    audio_fingerprint = ai.chromaprint.decode_fingerprint(bytes(audio_fingerprint))[0]

    jingle_fingerprint = es.Chromaprinter()(jingle)
    jingle_fingerprint = jingle_fingerprint.encode("utf-8")
    jingle_fingerprint = ai.chromaprint.decode_fingerprint(bytes(jingle_fingerprint))[0]

    jw = JingleWatch()
    result = None
    if duration_audio >= duration_jingle:
        result = jw.compare_fingerprints(audio_fingerprint, jingle_fingerprint)
    else:
        result = jw.compare_fingerprints(jingle_fingerprint, audio_fingerprint)

    # end = time.time()
    # print("time execution: ", end - start)
    # print("-- end --")

    return result

import essentia.standard as es
import acoustid as ai

from django.db import models
from django.utils import timezone
from django.utils.html import mark_safe
from django.utils.translation import gettext as _
from django.db.models.signals import pre_save, post_save, post_delete
from django.dispatch import receiver
from apps.record.models import Recording


class Jingle(models.Model):
    name = models.CharField(verbose_name=_("Name"), max_length=128)
    file = models.FileField(verbose_name=_("File"), upload_to="jingles/")
    duration = models.FloatField(verbose_name=_("Duration"), default=0)
    mime = models.CharField(verbose_name=_("MIME Type"), max_length=255)
    fingerprint = models.TextField(verbose_name=_("Fingerprint"))
    upload_ts = models.DateTimeField(default=timezone.now)
    active = models.BooleanField(verbose_name=_("Active"), default=True)

    def __str__(self):
        return self.name


@receiver(post_save, sender=Jingle)
def jingle_post_save(sender, instance: Jingle, **kwargs):
    """Generate fingerprint for uploaded jingle"""
    audio = es.MonoLoader(filename=instance.file.path)()
    duration = len(audio) / 44100

    fp_full_char = es.Chromaprinter()(audio)
    fp_full = ai.chromaprint.decode_fingerprint(bytes(fp_full_char.encode('utf-8')))[0]

    # instance.fingerprint = fp_full
    # instance.duration = duration
    Jingle.objects.filter(pk=instance.pk).update(fingerprint=fp_full, duration=duration)


@receiver(post_delete, sender=Jingle)
def jingle_post_delete(instance, *args, **kwargs):
    """Delete file after delete record"""
    instance.file.delete(save=False)


class JingleMatch(models.Model):
    jingle = models.ForeignKey(Jingle, on_delete=models.CASCADE)
    record = models.ForeignKey(Recording, on_delete=models.CASCADE)
    match_ts = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return "{} - {}".format(self.jingle.name, self.record.station)
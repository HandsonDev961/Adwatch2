# fmt: off
RADIOS = [
    {"station": "Brila FM sport FM",           "freq": 88.9},
    {"station": "Lasgidi Fm FM",               "freq": 90.1},
    {"station": "Top Radio FM",                "freq": 90.9},
    {"station": "Lagos Talks FM",              "freq": 91.3},
    {"station": "WFM 917[8] FM",               "freq": 91.7},
    {"station": "Inspiration FM",              "freq": 92.3},
    {"station": "Bond FM",                     "freq": 92.9},
    {"station": "Hot FM Lagos",                "freq": 93.3},
    {"station": "Rhythm FM",                   "freq": 93.7},
    {"station": "Rainbow FM",                  "freq": 94.1},
    {"station": "Wazobia FM",                  "freq": 95.1},
    {"station": "Urban96 FM",                  "freq": 96.5},
    {"station": "Cool FM",                     "freq": 96.9},
    {"station": "Metro FM",                    "freq": 97.7},
    {"station": "Smooth FM",                   "freq": 98.1},
    {"station": "Sound city FM",               "freq": 98.5},
    {"station": "Kiss FM",                     "freq": 98.9},
    {"station": "Nigeria Info FM",             "freq": 99.3},
    {"station": "Raypower FM",                 "freq": 100.5},
    {"station": "Max FM",                      "freq": 102.3},
    {"station": "NaijaFM",                     "freq": 102.7},
    {"station": "Radio FM",                    "freq": 103.5},
    {"station": "Kennis FM",                   "freq": 104.1},
    {"station": "City",                        "freq": 105.1},
    {"station": "Faaji FM",                    "freq": 106.5},
    {"station": "Radio Lagos",                 "freq": 107.5},
]

"""
RADCAP SET

radcap -c 0 -s 0 -f 88900
radcap -c 0 -s 1 -f 90100
radcap -c 0 -s 2 -f 90900
radcap -c 0 -s 3 -f 91300
radcap -c 0 -s 4 -f 91700
radcap -c 0 -s 5 -f 92300
radcap -c 0 -s 6 -f 92900
radcap -c 0 -s 7 -f 93300
radcap -c 0 -s 8 -f 93700
radcap -c 0 -s 9 -f 94100
radcap -c 0 -s 10 -f 95100
radcap -c 0 -s 11 -f 96500
radcap -c 0 -s 12 -f 96900
radcap -c 0 -s 13 -f 97700
radcap -c 0 -s 14 -f 98100
radcap -c 0 -s 15 -f 98500
radcap -c 0 -s 16 -f 98900
radcap -c 0 -s 17 -f 99300
radcap -c 0 -s 18 -f 100500
radcap -c 0 -s 19 -f 102300
radcap -c 0 -s 20 -f 102700
radcap -c 0 -s 21 -f 103500
radcap -c 0 -s 22 -f 104100
radcap -c 0 -s 23 -f 105100
radcap -c 0 -s 24 -f 106500
radcap -c 0 -s 25 -f 107500
radcap -c 0 -s 26 -f 0
radcap -c 0 -s 27 -f 0
radcap -c 0 -s 28 -f 0
radcap -c 0 -s 29 -f 0
radcap -c 0 -s 30 -f 0
radcap -c 0 -s 31 -f 0
"""

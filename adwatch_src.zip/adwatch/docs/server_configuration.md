# Server configuration

## Instructions

```bash
apt-get install python3 python3-venv python3-pip portaudio19-dev libchromaprint1 libchromaprint-tools
```

/*
 *   Driver for Sonifex AM Radcap PCIe card <www.sonifex.com.au>
 *   Copyright (c) 2012 by Jeff Pages <jeff@sonifex.com.au>
 *
 *   Derived from Ensoniq ES1370/ES1371 AudioPCI soundcard driver (ens1370.c)
 *   by Jaroslav Kysela and Thomas Sailer.
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 */

/* Power-Management-Code ( CONFIG_PM )
 * for ens1371 only ( FIXME )
 * derived from cs4281.c, atiixp.c and via82xx.c
 * using http://www.alsa-project.org/~tiwai/writing-an-alsa-driver/ 
 * by Kurt J. Bosch
 */

#include <asm/io.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/init.h>
#include <linux/pci.h>
#include <linux/slab.h>
#include <linux/gameport.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/videodev2.h>
#include <linux/sysfs.h>
#include <linux/version.h>

#include <sound/core.h>
#include <sound/control.h>
#include <sound/pcm.h>
#include <sound/initval.h>
#include <sound/asoundef.h>
#include <sound/tlv.h>
/* Codecs included the info.h, expecting it to be used in here too.  Bad programmers! */
#include <sound/info.h>

#ifndef RHEL_RELEASE_VERSION
#define RHEL_RELEASE_VERSION(a,b) (((a) << 8) + (b))
#endif

#ifndef RHEL_RELEASE_CODE
#define RHEL_RELEASE_CODE 0
#endif


#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,8,0)
/* These attributes are no longer supported */
#define __devinit
#define __devinitdata
#define __devinitconst
#define __devexit
#define __devexitdata
#define __devexitconst
#define __devexit_p(FUNC_NAME) FUNC_NAME
#endif

#define DRIVER_NAME "AMRADCAPPCIE"


MODULE_AUTHOR("Jeff Pages <jeff@sonfiex.com.au>");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Sonifex AM Radcap PCIe");
MODULE_SUPPORTED_DEVICE("{{Innescorp,AMRadcapPCIe}}");

#define MAX_STATIONS 32

static int index[SNDRV_CARDS] = SNDRV_DEFAULT_IDX;	/* Index 0-MAX */
static char *id[SNDRV_CARDS] = SNDRV_DEFAULT_STR;	/* ID for this card */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,8,0)
static bool enable[SNDRV_CARDS] = SNDRV_DEFAULT_ENABLE_PNP;	/* Enable switches */
#else
static int enable[SNDRV_CARDS] = SNDRV_DEFAULT_ENABLE_PNP;	/* Enable switches */
#endif
static int volatile ignore_first_interrupt[MAX_STATIONS];
static char *expansion_keys[SNDRV_CARDS] = { 0 };
static int key_count = 0;

module_param_array(index, int, NULL, 0444);
MODULE_PARM_DESC(index, "Index value for AM Radcap PCIe soundcard.");
module_param_array(id, charp, NULL, 0444);
MODULE_PARM_DESC(id, "ID string for AM Radcap PCIe soundcard.");
module_param_array(enable, bool, NULL, 0444);
MODULE_PARM_DESC(enable, "Enable AM Radcap PCIe soundcard.");

module_param_array(expansion_keys, charp, &key_count, 0444);
MODULE_PARM_DESC(expansion_keys, "Expansion key pairs HardwareID:ExpansionKey.");



/* Interrupt bits */

#define RADCAP_INTERRUPT_STREAM 0x0001
#define RADCAP_INTERRUPT_MONITOR_MID 0x0002
#define RADCAP_INTERRUPT_MONITOR_END 0x0004

struct station {
	struct kobject kobj;
	int index;
};

struct amradcap {
	spinlock_t reg_lock;

	int irq;

	unsigned int rev;	/* chip revision */

	uint32_t *control_status_memory;
	uint64_t *pagetable_memory;

	struct pci_dev *pci;
	struct snd_card *card;
	struct snd_pcm *pcm1;	/* ADC PCM */
	struct snd_pcm_substream *capture_substream[MAX_STATIONS];
	unsigned int c_dma_size[MAX_STATIONS];
	unsigned int c_period_size[MAX_STATIONS];
	unsigned int stream_state[MAX_STATIONS];

	unsigned int number_of_stations;
	unsigned int frequency[MAX_STATIONS];
	unsigned int fader[MAX_STATIONS][2];
	struct station *pstation[MAX_STATIONS];
	uint32_t expansion_key;
};


static irqreturn_t snd_audiopci_interrupt(int irq, void *dev_id);

#define	PCI_VENDOR_ID_INNES_CORP	0x1bc9

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 8, 0)
static const struct pci_device_id snd_amradcappcie_ids[] = {
#else
static DEFINE_PCI_DEVICE_TABLE(snd_amradcappcie_ids) = {
#endif
	{ PCI_VDEVICE(INNES_CORP, 0x3000), 0, },	/* AM Radcap PCIe */
	{ 0, }
};

MODULE_DEVICE_TABLE(pci, snd_amradcappcie_ids);

ssize_t show_band (struct device *dev, struct device_attribute *attrib, char *buffer) {
	return scnprintf (buffer, PAGE_SIZE, "AM\n");
}

ssize_t show_num_stations (struct device *dev, struct device_attribute *attrib, char *buffer) {
	struct pci_dev *pci = container_of (dev, struct pci_dev, dev);
	struct snd_card *card = pci_get_drvdata(pci);
	struct amradcap *pRadcap = card->private_data;
	return scnprintf (buffer, PAGE_SIZE, "%d\n", pRadcap->number_of_stations);
}


ssize_t show_hardware_id (struct device *dev, struct device_attribute *attrib, char *buffer) {
	struct pci_dev *pci = container_of (dev, struct pci_dev, dev);
	struct snd_card *card = pci_get_drvdata(pci);
	struct amradcap *pRadcap = card->private_data;
	unsigned int hardware_id_low = ioread32 (pRadcap->control_status_memory + 4);
	unsigned int hardware_id_high = ioread32 (pRadcap->control_status_memory + 5);
	return scnprintf (buffer, PAGE_SIZE, "%7.7x%8.8x\n", hardware_id_high, hardware_id_low);
}

ssize_t show_expansion_key (struct device *dev, struct device_attribute *attrib, char *buffer) {
	struct pci_dev *pci = container_of (dev, struct pci_dev, dev);
	struct snd_card *card = pci_get_drvdata(pci);
	struct amradcap *pRadcap = card->private_data;
	return scnprintf (buffer, PAGE_SIZE, "%u\n", pRadcap->expansion_key);
}

static struct attribute station_frequency =
{
	.name = "Frequency",
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,31)
	.owner = THIS_MODULE,
#endif
	.mode = 0666,
};

static struct attribute station_rssi =
{
	.name = "RSSI",
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,31)
	.owner = THIS_MODULE,
#endif
	.mode = 0444,
};

static struct attribute *station_attrs[] =
{
	&station_frequency,
	&station_rssi,
	NULL
};

static ssize_t station_show (struct kobject *kobj, struct attribute *attr, char *buffer) {
	if (kobj) {
		struct station *pstation = container_of (kobj, struct station, kobj);
		if (pstation && attr && buffer) {
			if (attr == &station_frequency)	{
				if (kobj->parent) {
					struct device *dev = container_of (kobj->parent, struct device, kobj);
					struct pci_dev *pci = container_of (dev, struct pci_dev, dev);
					struct snd_card *card = pci_get_drvdata(pci);
					struct amradcap *pRadcap = card->private_data;
					return scnprintf (buffer, PAGE_SIZE, "%d\n", pRadcap->frequency[pstation->index]);
				}
			}
			else if (attr == &station_rssi) {
				if (kobj->parent) {
					struct device *dev = container_of (kobj->parent, struct device, kobj);
					struct pci_dev *pci = container_of (dev, struct pci_dev, dev);
					struct snd_card *card = pci_get_drvdata(pci);
					struct amradcap *pRadcap = card->private_data;
					/* The card's RSSI port returns the signal strength in steps of 6/256 dB */
					int rssi = pRadcap->frequency[pstation->index] > 0 ? ioread32(pRadcap->control_status_memory + 0x60 + pstation->index) : 0;
					return scnprintf (buffer, PAGE_SIZE, "%d\n", rssi);
				}
			}
		}
	}
	return -EINVAL;
}

static ssize_t station_store (struct kobject *kobj, struct attribute *attr, const char *buffer, size_t size) {
	if (kobj) {
		struct station *pstation = container_of (kobj, struct station, kobj);
		if (pstation && attr && buffer) {
			if (attr == &station_frequency)	{
				char *endpoint;
				int frequency = simple_strtol (buffer, &endpoint, 10);
				struct device *dev = container_of (kobj->parent, struct device, kobj);
				struct pci_dev *pci = container_of (dev, struct pci_dev, dev);
				struct snd_card *card = pci_get_drvdata(pci);
				struct amradcap *pRadcap = card->private_data;
				if (frequency == 0 || (frequency >= 500 && frequency <= 1710)) {
					pRadcap->frequency[pstation->index] = frequency;
					iowrite32((pstation->index << 16) | ((frequency * 20480 / 441) & 0xffff), pRadcap->control_status_memory + 1);
				}
			}
		}
	}
	return size;
}

static void station_release (struct kobject *kobj) {
/*	if (kobj) kfree (kobj);	REVISION 1.0.2 ---- No, the kobj is part of the station structure which must be freed */
	if (kobj) {
		struct station *pstation = container_of (kobj, struct station, kobj);
		kfree (pstation);
	}
}


static struct sysfs_ops station_ops =
{
	.show = station_show,
	.store = station_store,
};

static struct kobj_type station_type =
{
	.release = station_release,
	.sysfs_ops = &station_ops,
	.default_attrs = station_attrs,
};

DEVICE_ATTR(band,0444,show_band,NULL);
DEVICE_ATTR(num_stations,0444,show_num_stations,NULL);
DEVICE_ATTR(hardware_id,0444,show_hardware_id,NULL);
DEVICE_ATTR(key,0444,show_expansion_key,NULL);

/*
 *  constants
 */


static int snd_amradcappcie_trigger(struct snd_pcm_substream *substream, int cmd)
{
	struct amradcap *pRadcap = snd_pcm_substream_chip(substream);
	switch (cmd) {
	case SNDRV_PCM_TRIGGER_PAUSE_PUSH:
		pRadcap->stream_state[substream->number] = 0x01;
		break;
	case SNDRV_PCM_TRIGGER_PAUSE_RELEASE:
		pRadcap->stream_state[substream->number] = 0x03;
		break;
	case SNDRV_PCM_TRIGGER_START:
		ignore_first_interrupt[substream->number] = 1;
		pRadcap->stream_state[substream->number] = 0x03;
		break;
	case SNDRV_PCM_TRIGGER_STOP:
		pRadcap->stream_state[substream->number] = 0x00;
		break;
	default:
		return -EINVAL;
	}
	iowrite32 (pRadcap->stream_state[substream->number], pRadcap->control_status_memory + 0x40 + substream->number);
	return 0;
}

/*
 *  PCM part
 */

static int snd_amradcappcie_hw_params(struct snd_pcm_substream *substream,
				 struct snd_pcm_hw_params *hw_params)
{
	return snd_pcm_lib_malloc_pages(substream, params_buffer_bytes(hw_params));
}

static int snd_amradcappcie_hw_free(struct snd_pcm_substream *substream)
{
	return snd_pcm_lib_free_pages(substream);
}

static int snd_amradcappcie_capture_prepare(struct snd_pcm_substream *substream)
{
	struct amradcap *pRadcap = snd_pcm_substream_chip(substream);
	struct snd_pcm_runtime *runtime = substream->runtime;
	u64 dma_page_address;
	unsigned int	page;

	pRadcap->c_dma_size[substream->number] = snd_pcm_lib_buffer_bytes(substream);
	pRadcap->c_period_size[substream->number] = snd_pcm_lib_period_bytes(substream);
	memset (runtime->dma_area, 0, pRadcap->c_dma_size[substream->number]);
	for (page = 0; page * 4096 < pRadcap->c_dma_size[substream->number]; page++) {
		dma_page_address = (snd_pcm_sgbuf_get_addr (substream, page * 4096) & 0xfffffffffffff000ULL);
		if (pRadcap->c_dma_size[substream->number] - page * 4096 <= 4096) {
			dma_page_address |= ((pRadcap->c_dma_size[substream->number] - page * 4096) & 0xffc) >> 2; /* Last page */
		}
		else {
			dma_page_address |= 0x400;	/* More pages to come */
		}
		iowrite32 ((u32) dma_page_address, (u32 *) (pRadcap->pagetable_memory + substream->number * 64 + page));
		iowrite32 ((u32) (dma_page_address >> 32), (u32 *) (pRadcap->pagetable_memory + substream->number * 64 + page) + 1);
	}
	iowrite32 (runtime->period_size * 16, pRadcap->control_status_memory + 4);	/* WARNING - could be a problem here if different substreams want to have different periods!! */
	return 0;
}

static snd_pcm_uframes_t snd_amradcappcie_capture_pointer(struct snd_pcm_substream *substream)
{
	struct amradcap *pRadcap = snd_pcm_substream_chip(substream);
	size_t ptr;

	spin_lock(&pRadcap->reg_lock);
	ptr = ioread32 (pRadcap->control_status_memory + 0x40 + substream->number);
 	spin_unlock(&pRadcap->reg_lock);
	return bytes_to_frames(substream->runtime, ptr);
}

static struct snd_pcm_hardware snd_amradcappcie_capture =
{
	.info =			(SNDRV_PCM_INFO_MMAP | SNDRV_PCM_INFO_INTERLEAVED |
				 SNDRV_PCM_INFO_BLOCK_TRANSFER |
				 SNDRV_PCM_INFO_MMAP_VALID | SNDRV_PCM_INFO_SYNC_START),
	.formats =		SNDRV_PCM_FMTBIT_S16_LE,
	.rates =		SNDRV_PCM_RATE_22050,
	.rate_min =		22050,
	.rate_max =		22050,
	.channels_min =		2,
	.channels_max =		2,
	.buffer_bytes_max =	(128*1024),
	.period_bytes_min =	64,
	.period_bytes_max =	11025,	// 125ms
	.periods_min =		2,
	.periods_max =		200,
	.fifo_size =		0,
};

static int snd_amradcappcie_capture_open(struct snd_pcm_substream *substream)
{
	struct amradcap *pRadcap = snd_pcm_substream_chip(substream);
	struct snd_pcm_runtime *runtime = substream->runtime;

	spin_lock_irq(&pRadcap->reg_lock);
	pRadcap->capture_substream[substream->number] = substream;
	spin_unlock_irq(&pRadcap->reg_lock);
	runtime->hw = snd_amradcappcie_capture;
	snd_pcm_set_sync(substream);
	pRadcap->fader[substream->number][0] = 0x8000;
	pRadcap->fader[substream->number][1] = 0x8000;
	iowrite32 ((pRadcap->fader[substream->number][1] << 16) | (pRadcap->fader[substream->number][0]), pRadcap->control_status_memory + 0x60 + substream->number);	/* Open the fader */
	return 0;
}

static int snd_amradcappcie_capture_close(struct snd_pcm_substream *substream)
{
	struct amradcap *pRadcap = snd_pcm_substream_chip(substream);

	spin_lock_irq(&pRadcap->reg_lock);
	pRadcap->capture_substream[substream->number] = NULL;
	pRadcap->stream_state[substream->number] = 0;
	iowrite32 (pRadcap->stream_state[substream->number], pRadcap->control_status_memory + 0x40 + substream->number);
	spin_unlock_irq(&pRadcap->reg_lock);
	return 0;
}


static struct snd_pcm_ops snd_amradcappcie_capture_ops = {
	.open =		snd_amradcappcie_capture_open,
	.close =	snd_amradcappcie_capture_close,
	.ioctl =    snd_pcm_lib_ioctl,
	.hw_params =	snd_amradcappcie_hw_params,
	.hw_free =	snd_amradcappcie_hw_free,
	.prepare =	snd_amradcappcie_capture_prepare,
	.trigger =	snd_amradcappcie_trigger,
	.pointer =	snd_amradcappcie_capture_pointer,
#if LINUX_VERSION_CODE < KERNEL_VERSION(5,5,0)
	.page    =	snd_pcm_sgbuf_ops_page,
#endif
};

static int __devinit snd_amradcappcie_pcm(struct amradcap * pRadcap, int device,
				     struct snd_pcm ** rpcm)
{
	struct snd_pcm *pcm;
	int err;

	if (rpcm)
		*rpcm = NULL;
	err = snd_pcm_new(pRadcap->card, "AMRadcapPCIe/0", device, 0, pRadcap->number_of_stations, &pcm);
	if (err < 0)
		return err;

	snd_pcm_set_ops(pcm, SNDRV_PCM_STREAM_CAPTURE, &snd_amradcappcie_capture_ops);

	pcm->private_data = pRadcap;
	pcm->info_flags = 0;
	strcpy(pcm->name, "AMRadcapPCIe Capture");
	pRadcap->pcm1 = pcm;

	snd_pcm_lib_preallocate_pages_for_all(pcm, SNDRV_DMA_TYPE_DEV_SG,
#if LINUX_VERSION_CODE < KERNEL_VERSION(5,5,0)	
		snd_dma_pci_data(pRadcap->pci), 64*1024, 128*1024);
#else
		&pRadcap->pci->dev, 64*1024, 128*1024);		
#endif

	if (rpcm)
		*rpcm = pcm;
	return 0;
}


/*
 *  Mixer section
 */
static DECLARE_TLV_DB_LINEAR(amradcap_lin_scale, TLV_DB_GAIN_MUTE, 600);
  
static int amradcap_fader_info(struct snd_kcontrol *kcontrol,
                               struct snd_ctl_elem_info *uinfo)
{
     uinfo->type = SNDRV_CTL_ELEM_TYPE_INTEGER;
     uinfo->count = 2;
     uinfo->value.integer.min = 0;
     uinfo->value.integer.max = 65535;
     return 0;
}

static int amradcap_fader_get(struct snd_kcontrol *kcontrol,
				   struct snd_ctl_elem_value *ucontrol)
{
	struct amradcap *pRadcap = snd_kcontrol_chip(kcontrol);
	
	spin_lock_irq(&pRadcap->reg_lock);
	ucontrol->value.integer.value[0] = pRadcap->fader[kcontrol->id.subdevice][0];
	ucontrol->value.integer.value[1] = pRadcap->fader[kcontrol->id.subdevice][1];
	spin_unlock_irq(&pRadcap->reg_lock);
	return 0;
}

static int amradcap_fader_put(struct snd_kcontrol *kcontrol,
				   struct snd_ctl_elem_value *ucontrol)
{
	struct amradcap *pRadcap = snd_kcontrol_chip(kcontrol);
	unsigned int nval[2];
	int change;
	
	nval[0] = ucontrol->value.integer.value[0];
	nval[1] = ucontrol->value.integer.value[1];
	spin_lock_irq(&pRadcap->reg_lock);
	change = pRadcap->fader[kcontrol->id.subdevice][0] != nval[0] || pRadcap->fader[kcontrol->id.subdevice][1] != nval[1];
	pRadcap->fader[kcontrol->id.subdevice][0] = nval[0];
	pRadcap->fader[kcontrol->id.subdevice][1] = nval[1];
	iowrite32 (nval[0] | (nval[1] << 16), pRadcap->control_status_memory + 0x60 + kcontrol->id.subdevice);
	spin_unlock_irq(&pRadcap->reg_lock);
	return change;
}

static struct snd_kcontrol_new amradcap_fader __devinitdata = {
          .iface = SNDRV_CTL_ELEM_IFACE_PCM,
          .name = "PCM Capture Volume",
          .index = 0,
          .access = SNDRV_CTL_ELEM_ACCESS_READWRITE | SNDRV_CTL_ELEM_ACCESS_TLV_READ,
          .private_value = 0,
          .info = amradcap_fader_info,
          .get = amradcap_fader_get,
          .put = amradcap_fader_put,
	  .tlv.p = amradcap_lin_scale
  };

static int __devinit snd_amradcappcie_mixer (struct amradcap * pRadcap)
{
	struct snd_card *card = pRadcap->card;
	unsigned int idx;
	int err;
	for (idx = 0; idx < pRadcap->number_of_stations; idx++) {
		pRadcap->fader[idx][0] = 0x8000;
		pRadcap->fader[idx][1] = 0x8000;
		amradcap_fader.subdevice = idx;
		err = snd_ctl_add(card, snd_ctl_new1(&amradcap_fader, pRadcap));
		if (err < 0) return err;
	}
	return 0;
}


/*

 */

static void snd_amradcappcie_proc_read(struct snd_info_entry *entry, 
				  struct snd_info_buffer *buffer)
{
	//struct amradcap *pRadcap = entry->private_data;

	snd_iprintf(buffer, "Sonifex AMRadcapPCIe\n\n");
}

static void __devinit snd_amradcappcie_proc_init(struct amradcap * pRadcap)
{
	struct snd_info_entry *entry;

	if (! snd_card_proc_new(pRadcap->card, "AMRadcapPCIe", &entry))
		snd_info_set_text_ops(entry, pRadcap, snd_amradcappcie_proc_read);
}

/*

 */

static int snd_amradcappcie_free(struct amradcap *pRadcap)
{
    iowrite32 (0, pRadcap->control_status_memory); /* Disable everything */
    iowrite32 (0, pRadcap->control_status_memory + 3);    /* Stop monitor interrupts */
	ioread32 (pRadcap->control_status_memory);	/* Make sure the above writes have been delivered before proceeding*/
	if (pRadcap->irq < 0)
		goto __hw_end;
	if (pRadcap->irq >= 0)
		synchronize_irq(pRadcap->irq);
	pci_set_power_state(pRadcap->pci, 3);
      __hw_end:
	if (pRadcap->pagetable_memory) iounmap (pRadcap->pagetable_memory);
	if (pRadcap->control_status_memory) iounmap (pRadcap->control_status_memory);
	if (pRadcap->irq >= 0)
		free_irq(pRadcap->irq, pRadcap);
	pci_release_regions(pRadcap->pci);
	pci_disable_device(pRadcap->pci);
	kfree(pRadcap);
	return 0;
}

static int snd_amradcappcie_dev_free(struct snd_device *device)
{
	struct amradcap *pRadcap = device->device_data;
	return snd_amradcappcie_free(pRadcap);
}

static void snd_amradcappcie_chip_init(struct amradcap *pRadcap)
{
	/* Check to see if there's an expansion key for this card */
	int i;
	int key;
	uint64_t HardwareId;
	((uint32_t *)(&HardwareId))[0] = ioread32(pRadcap->control_status_memory + 0x04);
	((uint32_t *)(&HardwareId))[1] = ioread32(pRadcap->control_status_memory + 0x05);
	for (key = 0; key < key_count; key++) {
		if (expansion_keys[key]) {
			uint64_t key_id = 0;
			unsigned int key_value = 0;
			int rc = sscanf (expansion_keys[key], "%15Lx:%u", &key_id, &key_value);
			if (rc == 2 && key_id == HardwareId) {
				iowrite32(key_value, pRadcap->control_status_memory + 0x05);
				pRadcap->expansion_key = key_value; 
			}
		}
	}
	/* Read number of channels from the card */
	pRadcap->number_of_stations = ioread32(pRadcap->control_status_memory + 0x00) & 0xffff;
	/* Enable the card's DMA and periodic interrupts */
	iowrite32 (0x11, pRadcap->control_status_memory);

	/* Set all the channels to STOP */
	for (i = 0; i < MAX_STATIONS; i++) {
		iowrite32 (0, pRadcap->control_status_memory + 0x40 + i);
	}
	synchronize_irq(pRadcap->irq);
#ifdef	INITIALISE_STATIONS
	{
		unsigned int INIT_CHAN;
		const unsigned int INIT_FREQ[MAX_STATIONS] = { 576, 630, 702, 873, 954, 1017, 1107, 1170, 1269, 0, };
		for (INIT_CHAN = 0; INIT_CHAN < pRadcap->number_of_stations; INIT_CHAN++) {
			pRadcap->frequency[INIT_CHAN] = INIT_FREQ[INIT_CHAN];
			iowrite32((INIT_CHAN << 16) | ((INIT_FREQ[INIT_CHAN] * 20480 / 441) & 0xffff), pRadcap->control_status_memory + 1);
		}
	}
#endif
}

#ifdef CONFIG_PM
static int snd_amradcappcie_suspend(struct pci_dev *pci, pm_message_t state)
{
	struct snd_card *card = pci_get_drvdata(pci);
	struct amradcap *pRadcap = card->private_data;

	snd_power_change_state(card, SNDRV_CTL_POWER_D3hot);

	snd_pcm_suspend_all(pRadcap->pcm1);

	/* Shut down the card */
	iowrite32 (0, pRadcap->control_status_memory);
	ioread32 (pRadcap->control_status_memory);

	pci_disable_device(pci);
	pci_save_state(pci);
	pci_set_power_state(pci, pci_choose_state(pci, state));
	return 0;
}

static int snd_amradcappcie_resume(struct pci_dev *pci)
{
	struct snd_card *card = pci_get_drvdata(pci);
	struct amradcap *pRadcap = card->private_data;
	int sub;

	pci_set_power_state(pci, PCI_D0);
	pci_restore_state(pci);
	if (pci_enable_device(pci) < 0) {
		printk(KERN_ERR DRIVER_NAME ": pci_enable_device failed, "
		       "disabling device\n");
		snd_card_disconnect(card);
		return -EIO;
	}
	pci_set_master(pci);

	snd_amradcappcie_chip_init(pRadcap);

	/* Restore the DMA scatter-gather table for any open streams */
	for (sub = 0; sub < MAX_STATIONS; sub++) {
		if (pRadcap->capture_substream[sub]) {
			unsigned int page;
			for (page = 0; page * 4096 < pRadcap->c_dma_size[sub]; page++) {
				u64 dma_page_address = (snd_pcm_sgbuf_get_addr (pRadcap->capture_substream[sub], page * 4096) & 0xfffffffffffff000ULL);
				if (pRadcap->c_dma_size[sub] - page * 4096 <= 4096) {
					dma_page_address |= ((pRadcap->c_dma_size[sub] - page * 4096) & 0xffc) >> 2; /* Last page */
				}
				else {
					dma_page_address |= 0x400;	/* More pages to come */
				}
				iowrite32 ((u32) dma_page_address, (u32 *) (pRadcap->pagetable_memory + sub * 64 + page));
				iowrite32 ((u32) (dma_page_address >> 32), (u32 *) (pRadcap->pagetable_memory + sub * 64 + page) + 1);
			}
			iowrite32 (pRadcap->capture_substream[sub]->runtime->period_size * 16, pRadcap->control_status_memory + 4);	/* WARNING - could be a problem here if different substreams want to have different periods!! */
			iowrite32 ((pRadcap->fader[sub][1] << 16) | (pRadcap->fader[sub][0]), pRadcap->control_status_memory + 0x60 + sub);	/* Open the fader */
			/* Restore the stream state */
			if (pRadcap->stream_state[sub] == 0x03) ignore_first_interrupt[sub] = 1;
			iowrite32 (pRadcap->stream_state[sub], pRadcap->control_status_memory + 0x40 + sub);
		}
	}
	snd_power_change_state(card, SNDRV_CTL_POWER_D0);
	return 0;
}

#endif /* CONFIG_PM */


static int __devinit snd_amradcappcie_create(struct snd_card *card,
				     struct pci_dev *pci,
				     struct amradcap ** ppRadcap)
{
	struct amradcap *pRadcap;
	int err;
	unsigned long control_status_physical_address;
	unsigned long pagetable_physical_address;
	unsigned long control_status_size;
	unsigned long pagetable_size;
	static struct snd_device_ops ops = {
		.dev_free =	snd_amradcappcie_dev_free,
	};

	*ppRadcap = NULL;
	if ((err = pci_enable_device(pci)) < 0)
		return err;
	pRadcap = kzalloc(sizeof(*pRadcap), GFP_KERNEL);
	if (pRadcap == NULL) {
		pci_disable_device(pci);
		return -ENOMEM;
	}
	spin_lock_init(&pRadcap->reg_lock);
	pRadcap->card = card;
	pRadcap->pci = pci;
	pRadcap->irq = -1;
	if ((err = pci_request_regions(pci, "InnesCorp AMRadcapPCIe")) < 0) {
		kfree(pRadcap);
		pci_disable_device(pci);
		return err;
	}
	control_status_physical_address = pci_resource_start(pci, 0);
	control_status_size = pci_resource_len(pci, 0);
	pRadcap->control_status_memory = ioremap(control_status_physical_address, control_status_size);
	pagetable_physical_address = pci_resource_start(pci, 2);
	pagetable_size = pci_resource_len(pci, 2);
	pRadcap->pagetable_memory = ioremap(pagetable_physical_address, pagetable_size);
	if (request_irq(pci->irq, snd_audiopci_interrupt, IRQF_SHARED,
			"InnesCorp AMRadcapPCIe", pRadcap)) {
		snd_printk(KERN_ERR "unable to grab IRQ %d\n", pci->irq);
		snd_amradcappcie_free(pRadcap);
		return -EBUSY;
	}
	pRadcap->irq = pci->irq;
	pci_set_master(pci);
	pRadcap->rev = pci->revision;
	pRadcap->expansion_key = 0;
	snd_amradcappcie_chip_init(pRadcap);

	if ((err = snd_device_new(card, SNDRV_DEV_LOWLEVEL, pRadcap, &ops)) < 0) {
		snd_amradcappcie_free(pRadcap);
		return err;
	}

	snd_amradcappcie_proc_init(pRadcap);

	snd_card_set_dev(card, &pci->dev);

	*ppRadcap = pRadcap;
	return 0;
}

/*
 *  Interrupt handler
 */

static irqreturn_t snd_audiopci_interrupt(int irq, void *dev_id)
{
	struct amradcap *pRadcap = dev_id;
	unsigned int status;

	if (pRadcap == NULL)
		return IRQ_NONE;

	status = ioread32 (pRadcap->control_status_memory + 1);
	if (!status)
		return IRQ_NONE;

	if ((status & RADCAP_INTERRUPT_STREAM)) {
		unsigned i;
		for (i = 0; i < pRadcap->number_of_stations; i++) {
			if (pRadcap->capture_substream[i]) {
				if (ignore_first_interrupt[i]) {
					ignore_first_interrupt[i] = 0;
				}
				else {
					snd_pcm_period_elapsed(pRadcap->capture_substream[i]);
				}
			}
		}
	}
	return IRQ_HANDLED;
}

static int __devinit snd_amradcappcie_probe(struct pci_dev *pci,
					const struct pci_device_id *pci_id)
{
	static int dev;
	struct snd_card *card;
	struct amradcap *pRadcap;
	int err;
	int i;

	if (dev >= SNDRV_CARDS)
		return -ENODEV;
	if (!enable[dev]) {
		dev++;
		return -ENOENT;
	}

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,16,0) && (!defined(RHEL_RELEASE_CODE) || RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(7,6))
	err = snd_card_create(index[dev], id[dev], THIS_MODULE, 0, &card);
#else
	err = snd_card_new(&pci->dev, index[dev], id[dev], THIS_MODULE, 0, &card);
#endif
	if (err < 0)
		return err;

	if ((err = snd_amradcappcie_create(card, pci, &pRadcap)) < 0) {
		snd_card_free(card);
		return err;
	}
	card->private_data = pRadcap;

	if ((err = snd_amradcappcie_mixer(pRadcap)) < 0) {
		snd_card_free(card);
		return err;
	}
	if ((err = snd_amradcappcie_pcm(pRadcap, 0, NULL)) < 0) {
		snd_card_free(card);
		return err;
	}

	strcpy(card->driver, DRIVER_NAME);

	strcpy(card->shortname, "Innes Corporation AMRadcapPCIe");
	sprintf(card->longname, "%s %s at %p, irq %i",
		card->shortname,
		card->driver,
		pRadcap->control_status_memory,
		pRadcap->irq);

	if ((err = snd_card_register(card)) < 0) {
		snd_card_free(card);
		return err;
	}

	pci_set_drvdata(pci, card);
	dev++;
	for (i = 0; i < pRadcap->number_of_stations; i++) {
		struct station *pstation = kzalloc(sizeof(struct station), GFP_KERNEL);
		if (pstation) {
			pstation->index = i;
			kobject_init (&pstation->kobj, &station_type);
/*			kobject_add (&pstation->kobj, &pci->dev.kobj, "Station%2.2d", i);	REVISION 1.0.2 ---- Check the return value of kobject_add and just delete the object if it fails */
			if (kobject_add (&pstation->kobj, &pci->dev.kobj, "Station%2.2d", i) >= 0) {
				pRadcap->pstation[i] = pstation;
			}
			else {
				kobject_put (&pstation->kobj);
				pRadcap->pstation[i] = NULL;
			}
			pRadcap->pstation[i] = pstation;
		}
	}
	device_create_file (&pci->dev, &dev_attr_band);
	device_create_file (&pci->dev, &dev_attr_num_stations);
	device_create_file (&pci->dev, &dev_attr_hardware_id);
	device_create_file (&pci->dev, &dev_attr_key);
	return 0;
}

static void __devexit snd_amradcappcie_remove(struct pci_dev *pci)
{
	struct snd_card *card = pci_get_drvdata(pci);
	if (card) {
		struct amradcap *pRadcap = card->private_data;
		if (pRadcap) {
			int i;
			for (i = 0; i < pRadcap->number_of_stations; i++) {
				if (pRadcap->pstation[i]) {
					kobject_del (&pRadcap->pstation[i]->kobj);
					kobject_put (&pRadcap->pstation[i]->kobj);
/*					kfree (pRadcap->pstation[i]);	REVISION 1.0.2 ---- Don't do this as the object is freed by the release function */
					pRadcap->pstation[i] = NULL;
				}
			}
		}
	}
	device_remove_file (&pci->dev, &dev_attr_key);
	device_remove_file (&pci->dev, &dev_attr_hardware_id);
	device_remove_file (&pci->dev, &dev_attr_num_stations);
	device_remove_file (&pci->dev, &dev_attr_band);
	snd_card_free(pci_get_drvdata(pci));
	pci_set_drvdata(pci, NULL);
}

static struct pci_driver driver = {
	.name = DRIVER_NAME,
	.id_table = snd_amradcappcie_ids,
	.probe = snd_amradcappcie_probe,
	.remove = __devexit_p(snd_amradcappcie_remove),
#ifdef CONFIG_PM
	.suspend = snd_amradcappcie_suspend,
	.resume = snd_amradcappcie_resume,
#endif
};

static int __init alsa_card_amradcappcie_init(void)
{
	return pci_register_driver(&driver);
}

static void __exit alsa_card_amradcappcie_exit(void)
{
	pci_unregister_driver(&driver);
}

module_init(alsa_card_amradcappcie_init)
module_exit(alsa_card_amradcappcie_exit)

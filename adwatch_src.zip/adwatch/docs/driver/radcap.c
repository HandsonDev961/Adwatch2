/*
 *	TODO:
 *	- hardware version checking (put into discovery routine and structure)
 *	- check that writing a key sets relevant number of stations immediately
 *	- set up driver with all 32 channels (ALSA requirement); have it manage what's visible
 *	- idle stations indicated how?  Freq == 0?
 */
// #define		FAKE_RADCAP

/*
 *  Setup program for Sonifex PCIe AM and FM Radcap cards
 *  Kevin Dawson, Nov 2012
 *  A rewrite of the version by Jeff Pages (Sonifex).
 *
 *  Usage:
 *	Overall, it is anticipated that a /etc/rc system startup script will restore configuration from a file
 *	and load it into the Radcap cards.
 *	At shutdown, the configuration will be stored back into that file.
 *	The "correct" file name is slightly dependent upon the OS flavour, but something conceptually related
 *	to the ALSA state file (eg /etc/radcap.conf or /var/lib/radcap/config) is likely to give good results.
 *
 *	There are 5 types of argument on the command line:
 *		Short option		Long option			Comments
 *	----------------------------------------------------------------------------------------------------
 *	FUNCTIONAL, not directly related to card configuration
 *		-h			--help				Display a usage text, regardless of other actions
 *		-v			--version			Version to use for storing Radcap config files
 *		-o			--store				Writes all configuration to a config file,
 *									rather than reading from it
 *	----------------------------------------------------------------------------------------------------
 *	CARD SPECIFIER, to specify which card is being addressed
 *		-i hardware_id		--identifier hardware_id	As set by the card
 *		-c alsa_number		--card alsa_number		As set by the kernel
 *	----------------------------------------------------------------------------------------------------
 *	CARD PARAMETER, to specify card-level parameters
 *		-k key			--key key			Expansion key
 *		-d deemphasis		--deemphasis deemphasis		50 or 75 (microseconds)
 *		-s station_number	--station station_number	0-based, maximum is set by expansion key
 *	----------------------------------------------------------------------------------------------------
 *	STATION PARAMETER, to specify individual station parameters
 *		-f frequency		--frequency frequency		kHz
 *		-m			--mono				Force mono reception
 *		-a			--auto				Automatic stereo/mono reception
 *		-n			--narrow			Narrow audio bandwidth
 *		-w			--wide				Wide audio bandwidth
 *	----------------------------------------------------------------------------------------------------
 *	FILE, which is any non-option argument (ie. it doesn't begin with '-')
 *		If there is a preceding --store argument, the file is written with the current configuration data,
 *		otherwise the file is read and its configuration information loaded.
 *	----------------------------------------------------------------------------------------------------
 *
 *	Arguments (including files) are processed in the order they are given.
 *	If no arguments are given, the configuration for all cards is reported to standard output.
 *	Multiple cards and stations can be programmed by giving multiple configuration information.
 *	If there is only a single Radcap card, it will be implicitly specified, so no -c or -i needed.
 *
 *	Card parameters require the card to be specified (either implicitly, or via ALSA number or hardware ID)
 *	and station parameters require a station number to be specified (which requires, in turn, a card specifier).
 *	Specifying a card or station without any configuration parameters causes the current configuration
 *	of that card or station to be displayed.
 *
 *	An unknown or out-of-range option will produce a diagnostic and a usage message but will otherwise be ignored.
 *
 *	Examples:
 *		Show the configuration for the first station on the first ALSA card:
 *		radcap -c 0 -s 0		# short options
 *		radcap --card 0 --station 0	# long options
 *
 *		Set its frequency:
 *		radcap -c 0 -s 0 -f 576
 *
 *		Show configuration for 2 cards, specified by hardware ID:
 *		radcap -i 0123456789abcdef -i fedcba9876543210
 *
 *		Set multiple stations on multiple cards (assuming card 0 is FM, card 1 is AM):
 *		radcap -c 0 -s 1 -f 105700 -s 2 -f 102500 -c 1 -s 3 -f 1539
 *
 *		And a sample of what's possible - load from a file, change a station and save to another file:
 *		radcap /etc/radcap.conf -c 0 -s 1 -a -o /tmp/newradcap
 *
 *
 *	Configuration file format (informal EBNF), loosely based on ALSA's asound.state
 *	The file is free-format, except that comments begin with the '#' character and continue to the end of the line.
 *	Sequences of alphanumeric characters forming adjacent lexical tokens are separated by white space.
 *	Symbols in < > are explained below.
 *	The choice between am-card-defn and fm-card-defn depends, of course, on the card type.
 *
 *		config-file = "version", <version>, { card-config } ;
 *		card-config = card-specifier, "{", card-defns, "}" ;
 *		card-specifier = "identifier", <hardware ID> | "card", <ALSA number> ;
 *		card-defns = { am-card-defn } | { fm-card-defn } ;
 *
 *		am-card-defn = "key", <expansion key> | am_station_defn ;
 *		am_station_defn = "station", <station number>, "{", am-station-params, "}" ;
 *		am-station-params = { "frequency", <valid AM frequency or 0> } ;
 *
 *		fm-card-defn = "key", <expansion key> | "deemphasis", ( "50" | "75" ) | fm-station-defn ;
 *		fm-station-defn = "station", <station number>, "{", fm-station-params, "}" ;
 *		fm-station-params = { "frequency", <valid FM frequency or 0> | "auto" | "mono" | "wide" | "narrow" } ;
 *
 *	Undefined symbols in the above:
 *		version: config file format version number
 *		hardware ID: the card's 64-bit serial number (specified in hexadecimal)
 *		ALSA number: the card's ALSA index as assigned by the kernel
 *		expansion key: specified in decimal
 *		station number: a decimal integer representing the station number on the card (zero-based)
 *		valid AM frequency: a decimal integer from AM_LOW to AM_HIGH, modulo AM_STEP (in kHz)
 *		valid FM frequency: a decimal integer from FM_LOW to FM_HIGH, modulo FM_STEP (in kHz)
 *	A frequency of 0 is used to disable the station.
 *
 *	It is highly recommended to use the hardware ID method to specify a card, rather than the ALSA number method
 *	as the ALSA number assigned to the card may change between boots.
 *	As with the command line parameters, the config file is processed in the order of its statements.
 */

/*
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 */

/*
 *	This is a config file version.
 *	Not a software version, not a hardware version - those are handled by the software.
 *
 *	Config file versions up to now:
 *		1	AM and FM PCIe cards only
 */
#define		RADFILE_VERSION		1

/* *This* is the software version :-)  Keep the format as YYYYMMDD so numeric comparisons can be made. */
#define		SOFTWARE_VERSION	((unsigned long) 20121201)

#include	<stdint.h>
#include	<stdlib.h>
#include	<stdio.h>
#include	<ctype.h>
#include	<errno.h>
#include	<string.h>
#include	<getopt.h>
#include	<dirent.h>
#include	<alsa/asoundlib.h>
#include	<linux/videodev2.h>

/* Why are these still not standard macros? */
#define		BIT(n)		(1 << (n))
#define		TAB_SIZE(t)	(sizeof (t) / sizeof (t[0]))

/* Frequency limits */
#define		AM_LOW	500
#define		AM_HIGH	1710
#define		AM_STEP	1

#define		FM_LOW	87500
#define		FM_HIGH	108500
#define		FM_STEP	1	/* The driver can manage it, the card even more so, so no need to restrict it here */

static	char *	myname;
static	int	arg_store	= 0;
static	int	file_version	= RADFILE_VERSION;
static	int	card_number	= -1;
static	int	station_number	= -1;

/* Bit field flags to indicate which parameters are valid, for printing out current state */
#define		P_CARD		BIT(0)
#define		P_STATION	BIT(1)
#define		P_PARAM		BIT(2)
static	int	params_set	= 0;

/* sysfs stuff: */

#define		ALSA_BASE	"/sys/class/sound"
#define		CARD_BASE	ALSA_BASE "/card%u/device"
#define		CARD_F(f)	f
#define		STATION_F(f)	CARD_F("Station%02u") "/" f

enum	radcap_type
{
	radcap_none,
	radcap_am,
	radcap_fm,
	radcap_all,
};

/* Structure for keeping track of all ALSA cards and knowing whether each is a Radcap (and which type) */
struct	alsa_card
{
	uint64_t		hardware_id;
	enum	radcap_type	type;
};

static	unsigned int		n_alsa_card;
static	struct alsa_card *	alsa_cards;
static	unsigned int		n_radcap;

/* Maximum length string to be read from a sysfs file - all the radcap sysfs files are reasonably short */
#define		STR_MAX		200

static	char	sysfs_id[]		= CARD_F("hardware_id");
static	char	sysfs_band[]		= CARD_F("band");
static	char	sysfs_key[]		= CARD_F("key");
static	char	sysfs_n_station[]	= CARD_F("num_stations");
static	char	sysfs_deemph[]		= CARD_F("deemphasis");
static	char	sysfs_freq[]		= STATION_F("Frequency");
static	char	sysfs_mono[]		= STATION_F("ForceMono");
static	char	sysfs_narrow[]		= STATION_F("NarrowAudio");
static	char	sysfs_rssi[]		= STATION_F("RSSI");

static	char	str_version[]	= "version";
static	char	str_id[]	= "identifier";
static	char	str_card[]	= "card";
static	char	str_am[]	= "AM";
static	char	str_fm[]	= "FM";
static	char	str_key[]	= "key";
static	char	str_station[]	= "station";
static	char	str_freq[]	= "frequency";
static	char	str_deemph[]	= "deemphasis";
static	char	str_wide[]	= "wide";
static	char	str_narrow[]	= "narrow";
static	char	str_auto[]	= "auto";
static	char	str_mono[]	= "mono";

/* Block delimiters in the config file */
static	char	str_opengroup[]		= "{";
static	char	str_closegroup[]	= "}";

/* For the conversion and reader/writer functions used below */
enum	io_result
{
	ior_ok,
	ior_bad_op,
	ior_no_file,
	ior_error,
	ior_bad_value,
};

/* read_file / write_file paths */
/* Caller can free the result when finished with it */
static	char *
make_path(uint32_t card, uint32_t station, char *f)
{
	char *	str;

	errno = 0;
	if (card < 0 || station < 0)
		return NULL;
	if ((str = malloc(sizeof CARD_BASE + 5 + strlen(f) + 1)) != NULL)
	{
		(void) sprintf(str, CARD_BASE "/", (unsigned int) card);
		(void) sprintf(str + strlen(str), f, (unsigned int) station);
	}
	return str;
}

/* Fatal error with a file - print an error message and die */
static	void
file_error(uint32_t card, uint32_t station, char *f)
{
	char *	errstr;

	errstr = strerror(errno);
	fprintf(stderr, "%s: %s (fatal)\n", make_path(card, station, f), errstr);
	exit(2);
}

/* General-purpose file reader */
/* Caller can free the result when finished with it */
static	enum	io_result
read_file(uint32_t card, uint32_t station, char *f, char **result)
{
	char *	path;
	FILE *	fp;
	size_t	len;

	if ((path = make_path(card, station, f)) == NULL)
		return ior_error;
	if ((*result = (char *) malloc(STR_MAX + 1)) == NULL)
		return ior_error;
#ifdef	FAKE_RADCAP
	unsigned int	rnum;
	static	char	*bands[]	= { str_am, str_fm };
	static	char	*deemphs[]	= { "50", "75" };
	unsigned int	freq;

	rnum = (unsigned int) rand();
	freq = (alsa_cards[card].type == radcap_am ? (AM_LOW + rnum % (AM_HIGH - AM_LOW + 1)) / 9 * 9 : (FM_LOW + rnum % (FM_HIGH - FM_LOW + 1)) / 50 * 50);
	if (strcmp(f, sysfs_id) == 0)
		(void) sprintf(*result, "%.8x%.8x", rand(), rnum);
	else if (strcmp(f, sysfs_band) == 0)
		(void) strcpy(*result, bands[rnum & 1]);
	else if (strcmp(f, sysfs_n_station) == 0)
		(void) sprintf(*result, "%u", 1 << (rnum % 6));
	else if (strcmp(f, sysfs_deemph) == 0)
		(void) strcpy(*result, deemphs[rnum & 1]);
	else if (strcmp(f, sysfs_key) == 0)
		(void) sprintf(*result, "%u", rnum);
	else if (strcmp(f, sysfs_freq) == 0)
		(void) sprintf(*result, "%u", freq);
	else if (strcmp(f, sysfs_rssi) == 0)
		(void) sprintf(*result, "%u", (rnum % 100) * (alsa_cards[card].type == radcap_am ? 256 : 128) / 6);
	else
		(void) sprintf(*result, "%u", rnum & 1);
//	printf("[read(%s) == '%s']\n", path, *result);
	free(path);
	return ior_ok;
#endif
	if ((fp = fopen(path, "r")) == NULL)
		return ior_no_file;
	free(path);
	len = fread(*result, 1, STR_MAX, fp);
	(void) fclose(fp);
	if (len > 0 && (*result)[len - 1] == '\n')
		len--;
	(*result)[len] = '\0';
	return ior_ok;
}

/* File writer */
static	enum	io_result
write_file(char *str, uint32_t card, uint32_t station, char *f)
{
	char *	path;
	FILE *	fp;

	if ((path = make_path(card, station, f)) == NULL)
		return ior_error;
#ifdef	FAKE_RADCAP
	printf("[write(%s, '%s')]\n", path, str);
	free(path);
	return ior_ok;
#endif
	if ((fp = fopen(path, "w")) == NULL)
		return ior_no_file;
	free(path);
	if (fputs(str, fp) == EOF || putc('\n', fp) == EOF || fclose(fp) == EOF)
		return ior_error;
	return ior_ok;
}

#define		TEXT_FUNC(str, fmt, val)	\
			if (str == NULL)			\
				str = malloc(20);		\
			if (str != NULL)			\
				(void) sprintf(str, fmt, val);	\
			return str;

/* Signed decimal number, at least 32 bits */
static	int
value_int(char *str)
{
	char *	endptr;
	long	result;

	result = strtol(str, &endptr, 10);
	return *str != '\0' && *endptr == '\0' ? (int) result : -1;
}

/* 32-bit unsigned decimal number */
static	enum	io_result
value_u32(char *str, uint32_t *value)
{
	char *	endptr;

	*value = (uint32_t) strtoul(str, &endptr, 10);
	return *str != '\0' && *endptr == '\0' ? ior_ok : ior_bad_value;
}

static	char *
text_u32(uint32_t value, char *str)
{
	TEXT_FUNC(str, "%lu", (unsigned long) value);
}

/* 64-bit hardware ID */
static	enum	io_result
value_id(char *str, uint64_t *value)
{
	char *	endptr;

	*value = (uint64_t) strtoull(str, &endptr, 0x10);
	return *str != '\0' && *endptr == '\0' ? ior_ok : ior_bad_value;
}

static	int
find_alsa_card(uint64_t id)
{
	unsigned int	n;

	for (n = 0; n < n_alsa_card; n++)
		if (alsa_cards[n].type != radcap_none && id == alsa_cards[n].hardware_id)
			return (int) n;
	return -1;
}

static	char *
text_id(uint64_t id, char *str)
{
	TEXT_FUNC(str, "%.15llx", (unsigned long long) id);
}

/* Band */
static	enum	io_result
value_band(char *str, enum radcap_type *value)
{
	if (strcmp(str, str_am) == 0)
		*value = radcap_am;
	else if (strcmp(str, str_fm) == 0)
		*value = radcap_fm;
	else
		return ior_bad_value;
	return ior_ok;
}

static	char *
text_band(enum radcap_type value, char *str)
{
	if (str == NULL)
		str = malloc(10);
	if (str != NULL)
	{
		if (value == radcap_am)
			(void) strcpy(str, str_am);
		else if (value == radcap_fm)
			(void) strcpy(str, str_fm);
		else
			(void) strcpy(str, "?");
	}
	return str;
}

/* Frequency, with range checking relevant to the band */
static	enum	io_result
value_freq(char *str, uint32_t *value)
{
	enum	io_result	ior;

	if (card_number < 0 || station_number < 0)
		return ior_bad_op;
	if (value_u32(str, value) != ior_ok)
		return ior_bad_value;
	if (*value == 0)
		return ior_ok;
	switch (alsa_cards[card_number].type)
	{
	case radcap_am:
		return *value >= AM_LOW && *value <= AM_HIGH && (*value % AM_STEP) == 0 ? ior_ok : ior_bad_value;

	case radcap_fm:
		return *value >= FM_LOW && *value <= FM_HIGH && (*value % FM_STEP) == 0 ? ior_ok : ior_bad_value;
	}
	return ior_bad_op;
}

/* RSSI - scaled different ways for each band */
static	int
value_rssi(char *str, enum radcap_type rt)
{
	enum	io_result	ior;
	int			rssi;

	rssi = value_int(str);
	if (rt == radcap_am)
	{
		rssi *= 6;
		rssi /= 256;
	}
	else if (rt == radcap_fm)
	{
		rssi *= 6;
		rssi /= 128;
	}
	else
		rssi = -1;
	return rssi;
}

/* Discover which sound interfaces are Radcap */
static	void
discover_radcap(void)
{
	struct	dirent *	dent;
	DIR *			dir;
	unsigned int		n;
	unsigned int		last_discovered;

	n_alsa_card = 0;
	alsa_cards = NULL;
	if ((dir = opendir(ALSA_BASE)) == NULL)
		return;
	while ((dent = readdir(dir)) != NULL)
		if (sscanf(dent->d_name, "card%u", &n) == 1)
			if ((size_t) n + 1 > n_alsa_card)
				n_alsa_card = (size_t) n + 1;
	if ((alsa_cards = malloc(n_alsa_card * sizeof (struct alsa_card))) == NULL)
		n_alsa_card = 0;
	n_radcap = 0;
	if (n_alsa_card != 0)
	{
		for (n = 0; n < (unsigned int) n_alsa_card; n++)
			alsa_cards[n].type = radcap_none;
		rewinddir(dir);
		while ((dent = readdir(dir)) != NULL)
		{
			char *	str;

			if (sscanf(dent->d_name, "card%u", &n) != 1)
				continue;
			if (n >= n_alsa_card)	/* should never happen! */
				continue;
			if (read_file(n, 0, sysfs_id, &str) != ior_ok
			  || value_id(str, &alsa_cards[n].hardware_id) != ior_ok)
				continue;
			if (read_file(n, 0, sysfs_band, &str) != ior_ok
			  || value_band(str, &alsa_cards[n].type) != ior_ok)
				continue;
			last_discovered = n;
			n_radcap++;
		}
	}
	if (n_radcap == 1)
		card_number = (int) last_discovered;
	(void) closedir(dir);
}

/* Print a station, or all stations on a card */
/* TODO: Merge the duplicated code */
static	void
print_station(unsigned int acard, unsigned int stn)
{
	char *	str;
	char	buf[20];

	printf("Radcap %s (ALSA %2u), station %2u:", text_id(alsa_cards[acard].hardware_id, buf), acard, stn);
	if (read_file(acard, stn, sysfs_freq, &str) != ior_ok)
		file_error(acard, stn, sysfs_freq);
	printf(" %6dkHz", value_int(str));
	buf[0] = '\0';
	if (alsa_cards[acard].type == radcap_fm)
	{
		if (read_file(acard, stn, sysfs_mono, &str) != ior_ok)
			file_error(acard, stn, sysfs_mono);
		(void) strcat(buf, value_int(str) == 0 ? str_auto : str_mono);
		(void) strcat(buf, ", ");
		if (read_file(acard, stn, sysfs_narrow, &str) != ior_ok)
			file_error(acard, stn, sysfs_narrow);
		(void) strcat(buf, value_int(str) == 0 ? str_wide : str_narrow);
		(void) strcat(buf, ",");
	}
	printf(" %-13s", buf);
	if (read_file(acard, stn, sysfs_rssi, &str) != ior_ok)
		file_error(acard, stn, sysfs_rssi);
	printf(" RSSI %3ddB", value_rssi(str, alsa_cards[acard].type));
	putchar('\n');
}

static	void
print_config(unsigned int acard)
{
	char		buf[20];	/* longest string being printed is a hardware ID (16 chars) */
	char *		str;
	int		num_stations;
	int		stn;
	uint32_t	key;
	int		ncol, col;
	int		offset, off;

	putchar('\n');
	if (read_file(acard, 0, sysfs_n_station, &str) != ior_ok)
		file_error(acard, 0, sysfs_n_station);
	num_stations = value_int(str);
	printf("ALSA card %u: ", acard);
	printf("hardware ID %s, ", text_id(alsa_cards[acard].hardware_id, buf));
	printf("%s, ", text_band(alsa_cards[acard].type, buf));
	if (alsa_cards[acard].type == radcap_fm)
	{
		if (read_file(acard, 0, sysfs_deemph, &str) != ior_ok)
			file_error(acard, 0, sysfs_deemph);
		printf("deemphasis %dus, ", value_int(str));
	}
	if (read_file(acard, 0, sysfs_key, &str) != ior_ok)
	{
		printf("no expansion key, ");
	}
	else
	{
		(void) value_u32(str, &key);
		if (key == 0)
		{
			printf("no expansion key, ");
		}
		else
		{
			printf("expansion key %lu, ", (unsigned long) key);
		}
	}
	printf("%d station%s\n", num_stations, (num_stations == 1 ? "" : "s"));
	if (num_stations > 0)
	{
		ncol = (num_stations < 4 ? num_stations : 4);
		if (num_stations > 3 && alsa_cards[acard].type == radcap_fm)
			ncol = 3;
		offset = (num_stations + ncol - 1) / ncol;
		if (alsa_cards[acard].type == radcap_am)
			str = "";
		else if (alsa_cards[acard].type == radcap_fm)
			str = " stereo audio ";
		else
			str = " ??";
		for (col = 0; col < ncol; col++)
		{
			if (col != 0)
				printf(" |");
			printf(" Stn %6s%s %4s", "kHz", str, "RSSI");
		}
		putchar('\n');
		for (col = 0; col < ncol; col++)
		{
			int	i;
	
			if (col != 0)
				printf("-+");
			for (i = 16 + strlen(str); i != 0; i--)
				putchar('-');
		}
		putchar('\n');
		for (off = 0; off < offset; off++)
		{
			for (col = 0; col < ncol; col++)
			{
				if (col != 0)
					printf(" |");
				stn = col * offset + off;
				if (stn >= num_stations)
					continue;
				printf(" %2d:", stn);
				if (read_file(acard, stn, sysfs_freq, &str) != ior_ok)
					file_error(acard, stn, sysfs_freq);
				printf(" %6d", value_int(str));
				if (alsa_cards[acard].type == radcap_fm)
				{
					if (read_file(acard, stn, sysfs_mono, &str) != ior_ok)
						file_error(acard, stn, sysfs_mono);
					printf(" %-6s", value_int(str) == 0 ? str_auto : str_mono);
					if (read_file(acard, stn, sysfs_narrow, &str) != ior_ok)
						file_error(acard, stn, sysfs_narrow);
					printf(" %-6s", value_int(str) == 0 ? str_wide : str_narrow);
				}
				if (read_file(acard, stn, sysfs_rssi, &str) != ior_ok)
					file_error(acard, stn, sysfs_rssi);
				printf(" %4d", value_rssi(str, alsa_cards[acard].type));
			}
			putchar('\n');
		}
	}
}

/* Parser routines for loading from a file */

struct	token_list
{
	int			short_option;	/* Short option from the command line */
	int			has_group;	/* Whether it takes a subgroup */
	enum	radcap_type	type;		/* Card type */
	int			(*handler)(char *, char *);	/* arg, sysfs file */
	char *			file;		/* sysfs file */

	/* Pointer back to getopt table - set by software */
	struct	option *	option;
};

static	struct	token_list *
find_token_list(size_t n_entry, struct token_list *list, int opt)
{
	for ( ; n_entry != 0; n_entry--, list++)
		if (opt == list->short_option)
			return list;
	return NULL;
}

static	int
load_version(char *arg, char *file)
{
	int	version;

	if ((version = value_int(arg)) < 1 || version > RADFILE_VERSION)
	{
		fprintf(stderr, "Can't handle version '%s' files\n", arg);
		return 1;
	}
	file_version = version;
	return 0;
}

static	int
load_id(char *arg, char *file)
{
	uint64_t	id;

	card_number = -1;
	station_number = -1;
	if (value_id(arg, &id) != ior_ok)
	{
		fprintf(stderr, "Invalid card ID '%s'\n", arg);
		return 1;
	}
	if ((card_number = find_alsa_card(id)) < 0)
	{
		char	buf[20];

		fprintf(stderr, "No Radcap card found with ID %s\n", text_id(id, buf));
		return 1;
	}
	params_set = P_CARD;
	return 0;
}

static	int
load_card(char *arg, char *file)
{
	int	acard;

	card_number = -1;
	station_number = -1;
	if ((acard = value_int(arg)) == -1)
	{
		fprintf(stderr, "Invalid ALSA card number '%s'\n", arg);
		return 1;
	}
	if (acard < 0 || acard >= n_alsa_card)
	{
		fprintf(stderr, "Card number %d is not a known ALSA card\n", acard);
		return 1;
	}
	if (alsa_cards[acard].type == radcap_none)
	{
		fprintf(stderr, "ALSA card %d is not a Radcap\n", acard);
		return 1;
	}
	card_number = acard;
	params_set = P_CARD;
	return 0;
}

static	int
load_key(char *arg, char *file)
{
	uint32_t	key;

	params_set |= P_PARAM;
	if (value_u32(arg, &key) != ior_ok)
	{
		fprintf(stderr, "Invalid key '%s'\n", arg);
		return 1;
	}
	if (write_file(arg, card_number, 0, file) != ior_ok)
	{
		//file_error(card_number, 0, file);
		return 2;
	}
	return 0;
}

static	int
load_station(char *arg, char *file)
{
	char *	str;
	int	stn;
	int	num_stations;

	station_number = -1;
	if (read_file(card_number, 0, sysfs_n_station, &str) != ior_ok)
	{
		file_error(card_number, 0, sysfs_n_station);
		return 2;
	}
	num_stations = value_int(str);
	free(str);
	stn = value_int(arg);
	if (stn >= num_stations)
	{
		fprintf(stderr, "Card %u has stations in range 0 .. %u\n", card_number, num_stations - 1);
		return 1;
	}
	station_number = stn;
	params_set |= P_STATION;
	return 0;
}

static	int
load_deemph(char *arg, char *file)
{
	int	deemphasis;

	params_set |= P_PARAM;
	if (alsa_cards[card_number].type != radcap_fm)
	{
		fprintf(stderr, "Deemphasis applies only to FM cards\n");
		return 1;
	}
	if ((deemphasis = value_int(arg)) != 50 && deemphasis != 75)
	{
		fprintf(stderr, "Deemphasis must be 50 or 75 microseconds\n");
		return 1;
	}
	if (write_file(arg, card_number, 0, file) != ior_ok)
	{
		file_error(card_number, 0, file);
		return 2;
	}
	return 0;
}

static	int
load_stn_param(char *str, char *file)
{
	if (write_file(str, card_number, station_number, file) != ior_ok)
	{
		file_error(card_number, 0, file);
		return 2;
	}
	return 0;
}

static	int
load_freq(char *arg, char *file)
{
	uint32_t	freq;

	params_set |= P_PARAM;
	if (value_freq(arg, &freq) != ior_ok)
	{
		fprintf(stderr, "Invalid frequency\n");
		return 1;
	}
	return load_stn_param(arg, file);
}

static	int
load_0(char *arg, char *file)
{
	params_set |= P_PARAM;
	return load_stn_param("0", file);
}

static	int
load_1(char *arg, char *file)
{
	params_set |= P_PARAM;
	return load_stn_param("1", file);
}

static	struct	token_list	token_cardspec[]	=
{
	{ 'v',	0,	radcap_all,	load_version,	NULL		},
	{ 'i',	1,	radcap_all,	load_id,	NULL		},
	{ 'c',	1,	radcap_all,	load_card,	NULL		},
};

static	struct	token_list	token_cardparam[]	=
{
	{ 'k',	0,	radcap_all,	load_key,	sysfs_key	},
	{ 's',	1,	radcap_all,	load_station,	NULL		},
	{ 'd',	0,	radcap_fm,	load_deemph,	sysfs_deemph	},
};

static	struct	token_list	token_stationparam[]	=
{
	{ 'f',	0,	radcap_all,	load_freq,	sysfs_freq	},
	{ 'w',	0,	radcap_fm,	load_0,		sysfs_narrow	},
	{ 'n',	0,	radcap_fm,	load_1,		sysfs_narrow	},
	{ 'a',	0,	radcap_fm,	load_0,		sysfs_mono	},
	{ 'm',	0,	radcap_fm,	load_1,		sysfs_mono	},
};

struct	token_table
{
	size_t			n_list;
	struct	token_list *	list;
};

static	struct	token_table	token_table[]	=
{
	{ TAB_SIZE(token_cardspec),	token_cardspec		},
	{ TAB_SIZE(token_cardparam),	token_cardparam		},
	{ TAB_SIZE(token_stationparam),	token_stationparam	},
};

/*
 *	Options table is here because it's used below.
 *	It can probably be constructed from the token lists above (with another list for "help" and "store"),
 *	but I tried that once and it kept getting worse when I put other sensible stuff in there.
 */

/* Even after all these years, getopt() is still a crock */
static	struct	option	long_options[]	=
{
	{ "help",	no_argument,		NULL,		'h'	},
	{ str_version,	required_argument,	NULL,		'v'	},
	{ "store",	no_argument,		NULL,		'o'	},
	{ str_id,	required_argument,	NULL,		'i'	},
	{ str_card,	required_argument,	NULL,		'c'	},
	{ str_key,	required_argument,	NULL,		'k'	},
	{ str_deemph,	required_argument,	NULL,		'd'	},
	{ str_station,	required_argument,	NULL,		's'	},
	{ str_freq,	required_argument,	NULL,		'f'	},
	{ str_mono,	no_argument,		NULL,		'm'	},
	{ str_auto,	no_argument,		NULL,		'a'	},
	{ str_narrow,	no_argument,		NULL,		'n'	},
	{ str_wide,	no_argument,		NULL,		'w'	},
	{ (char *) 0,	0,			(int *) 0,	0	}
};

/* And right now I feel hf:v:s:i:c:k:d:woman because hf:d:v:s:i:c:k:woman */
static	char		short_options[]	= "-:hv:oi:c:k:d:s:f:manw";

/* Feed pointers to the long option entries back into token tables */
static	void
link_tables(void)
{
	int	n1, n2, n3;

	for (n1 = 0; n1 < TAB_SIZE(token_table); n1++)
		for (n2 = 0; n2 < token_table[n1].n_list; n2++)
			for (n3 = 0; long_options[n3].val != 0; n3++)
				if (token_table[n1].list[n2].short_option == long_options[n3].val)
					token_table[n1].list[n2].option = &long_options[n3];
}

/* Reads a token from a file */
/* A token is either a sequence of alphanumeric characters, or a single punctuation character */
/* Comments are passed over on the way */

static	unsigned int	lineno;

static	int
skip_space(FILE *fp)
{
	int	ch;

	for ( ; ; )
	{
		while ((ch = getc(fp)) != EOF)
		{
			if (ch == '\n')
				lineno++;
			if (!isspace(ch))
				break;
		}
		if (ch != '#')
			return ch;
		while ((ch = getc(fp)) != EOF && ch != '\n')
			;
		lineno++;
	}
}

static	size_t
get_token(FILE *fp, size_t buflen, char *buf)
{
	int	ch;
	size_t	len;

	if (buflen < 2)
		return -1;
	ch = skip_space(fp);
	len = 0;
	if (isalnum(ch))
	{
		do
		{
			if (len < buflen - 1)
				buf[len++] = (char) ch;
			ch = getc(fp);
		} while (isalnum(ch));
		(void) ungetc(ch, fp);
	}
	else if (ch != EOF)
	{
		buf[0] = (char) ch;
		len = 1;
	}
	buf[len] = '\0';
	return len;
}

static	int
load_config(char *f)
{
	FILE *			fp;
	int			ch;
	char			buf[20];
	size_t			len;
	int			level;
	int			n_list;
	int			nl;
	struct	token_list *	tlist;
	int			rets;

	if ((fp = fopen(f, "r")) == NULL)
	{
		fprintf(stderr, "%s: %s\n", f, strerror(errno));
		return 1;
	}
	rets = BIT(0);
	level = 0;
	lineno = 1;
	while ((len = get_token(fp, sizeof buf, buf)) > 0)
	{
		n_list = token_table[level].n_list;
		tlist = token_table[level].list;
		if (strcmp(buf, str_closegroup) == 0)
		{
			if (level == 0)
			{
				fprintf(stderr, "%s line %d: Closing a group but not within one\n", f, lineno);
				rets |= BIT(1);
			}
			else
				level--;
			continue;
		}
		for (nl = 0; nl < n_list; nl++, tlist++)
			if (strcmp(buf, tlist->option->name) == 0)
			{
				int	fret;

				if (tlist->option->has_arg)
				{
					if ((len = get_token(fp, sizeof buf, buf)) == 0)
					{
						fprintf(stderr, "%s line %d: %s requires an argument\n",
						  f, lineno, tlist->option->name);
						rets |= BIT(1);
					}
				}
				fret = (*tlist->handler)(buf, tlist->file);
				rets |= BIT(fret);
				if (tlist->has_group)
				{
					if ((len = get_token(fp, sizeof buf, buf)) == 0 || strcmp(buf, str_opengroup) != 0)
					{
						fprintf(stderr, "%s line %d: '%s' requires a '%s %s' sub-group\n",
						  f, lineno, tlist->option->name, str_opengroup, str_closegroup);
						rets |= BIT(1);
					}
					else
						level++;
				}
				break;
			}
		if (nl >= n_list)
		{
			fprintf(stderr, "%s line %d: '%s' not recognised at level %d\n", f, lineno, buf, level);
			rets |= BIT(1);
		}
	}
	if (level != 0)
	{
		fprintf(stderr, "%s line %d: Premature EOF inside sub-group\n", f, lineno);
		rets |= BIT(1);
	}
	if (fclose(fp) != 0)
	{
		/* Failing to close a read-only file should never happen! */
		fprintf(stderr, "%s line %d: %s\n", f, lineno, strerror(errno));
		rets |= BIT(2);
	}
	for (nl = 0; nl < sizeof (int) * 8; nl++)
	{
		if ((rets & ~BIT(nl)) == 0)
			break;
		rets &= ~BIT(nl);
	}
	return nl;
}

static	int
store_1_config(unsigned int acard, FILE *fp)
{
	char		buf[20];
	char *		str;
	int		num_stations;
	int		stn;
	uint32_t	key;
	int		width;

	fprintf(fp, "\n%s %s\n%s\n", str_id, text_id(alsa_cards[acard].hardware_id, buf), str_opengroup);
	fprintf(fp, "\t# ALSA card %u\n", acard);
	if (read_file(acard, 0, sysfs_n_station, &str) != ior_ok)
		file_error(acard, 0, sysfs_n_station);
	num_stations = value_int(str);
	fprintf(fp, "\t# %s, %d station%s\n", text_band(alsa_cards[acard].type, buf), num_stations, (num_stations == 1 ? "" : "s"));
	if (alsa_cards[acard].type == radcap_fm)
	{
		if (read_file(acard, 0, sysfs_deemph, &str) != ior_ok)
			file_error(acard, 0, sysfs_deemph);
		fprintf(fp, "\t%s %d\n", str_deemph, value_int(str));
	}
	if (read_file(acard, 0, sysfs_key, &str) != ior_ok)
	{
		fprintf(fp, "\t# no expansion\n");
	}
	else
	{
		(void) value_u32(str, &key);
		fprintf(fp, "\t%s %s\n", str_key, text_u32(key, buf));
	}
	width = (alsa_cards[acard].type == radcap_am ? 4 : 6);
	for (stn = 0; stn < num_stations; stn++)
	{
		fprintf(fp, "\t%s %2d %s ", str_station, stn, str_opengroup);
		if (read_file(acard, stn, sysfs_freq, &str) != ior_ok)
			file_error(acard, stn, sysfs_freq);
		fprintf(fp, "%s %*d", str_freq, width, value_int(str));
		if (alsa_cards[acard].type == radcap_fm)
		{
			if (read_file(acard, stn, sysfs_mono, &str) != ior_ok)
				file_error(acard, stn, sysfs_mono);
			fprintf(fp, " %-4s", value_int(str) == 0 ? str_auto : str_mono);
			if (read_file(acard, stn, sysfs_narrow, &str) != ior_ok)
				file_error(acard, stn, sysfs_narrow);
			fprintf(fp, " %-6s", value_int(str) == 0 ? str_wide : str_narrow);
		}
		fprintf(fp, " %s  ", str_closegroup);
		if (read_file(acard, stn, sysfs_rssi, &str) != ior_ok)
			file_error(acard, stn, sysfs_rssi);
		fprintf(fp, "# RSSI %3ddB\n", value_rssi(str, alsa_cards[acard].type));
	}
	fprintf(fp, "%s\n", str_closegroup);
}

static	int
store_config(char *f)
{
	FILE *		fp;
	unsigned int	acard;

	if ((fp = fopen(f, "w")) == NULL)
	{
		return 2;
	}
	fprintf(fp, "# Sonifex Radcap\n");
	fprintf(fp, "# Software date %lu\n", SOFTWARE_VERSION);
	fprintf(fp, "# %u Radcap card%s discovered\n\n", n_radcap, n_radcap != 1 ? "s" : "");
	fprintf(fp, "%s %u\n", str_version, file_version);
	for (acard = 0; acard < n_alsa_card; acard++)
		if (alsa_cards[acard].type != radcap_none)
			store_1_config(acard, fp);
	if (fclose(fp) == EOF)
	{
		return 2;
	}
	return 0;
}

/* Command line / config file stuff: */

static	int
do_opt(int opt, char *arg)
{
	struct	token_list *	tlist;
	const	char *		longopt;
	int			spec_opt;
	int			n;
	int			ret;
	char			buf[20];

	spec_opt = (opt != ':' ? opt : optopt);
	longopt = NULL;
	for (n = 0; long_options[n].val != 0; n++)
		if (long_options[n].val == spec_opt)
			longopt = long_options[n].name;
	switch (opt)
	{
	case 1:
		/* non-option (ie, a file) */
		if (arg_store)
			return store_config(optarg);
		n = params_set;
		ret = load_config(optarg);
		params_set = n;
		return ret;

	case '?':
		/* unknown option */
		if (optopt != 0)
			fprintf(stderr, "unknown short option: '%c'\n", optopt);
		else
			fprintf(stderr, "unknown long option: '%s'\n", arg);
		return 1;

	case ':':
		/* option missing its arg */
		fprintf(stderr, "option '%c' (%s) missing its argument\n", optopt, longopt);
		return 1;

	case 'h':
		printf("Sonifex Radcap card configuration manager\n");
		printf("Software date %lu, config file version %u\n", SOFTWARE_VERSION, RADFILE_VERSION);
		printf("Usage: %s [option]...\n", myname);
		for (n = 0; long_options[n].val != 0; n++)
		{
			(void) sprintf(buf, "%c", long_options[n].val);
			if (long_options[n].has_arg != no_argument)
				(void) sprintf(&buf[strlen(buf)], " %s", long_options[n].name);
			printf("    -%-20s    --%s", buf, long_options[n].name);
			if (long_options[n].has_arg != no_argument)
				printf(" %s", long_options[n].name);
			putchar('\n');
		}
		printf("See the manual page for further information\n");
		return 0;

	case 'o':
		arg_store++;
		return 0;

	case 'i':
	case 'c':
		if ((params_set & (P_CARD | P_PARAM)) == P_CARD)
			if (params_set & P_STATION)
				print_station(card_number, station_number);
			else
				print_config(card_number);
		params_set = 0;
		/* No break */
	case 'v':
		if ((tlist = find_token_list(TAB_SIZE(token_cardspec), token_cardspec, opt)) == NULL)
			return 2;
		return (*tlist->handler)(optarg, tlist->file);

	case 's':
		if ((params_set & (P_STATION | P_PARAM)) == P_STATION)
			print_station(card_number, station_number);
		params_set = P_CARD;
		/* No break */
	case 'k':
	case 'd':
		if ((tlist = find_token_list(TAB_SIZE(token_cardparam), token_cardparam, opt)) == NULL)
			return 2;
		if (card_number < 0)
		{
			fprintf(stderr, "Radcap card must be specified for %s\n", longopt);
			return 1;
		}
		if (tlist->type != alsa_cards[card_number].type && tlist->type != radcap_all)
		{
			fprintf(stderr, "Radcap ID %s (ALSA %d) does not handle '%s'\n",
			  text_id(alsa_cards[card_number].hardware_id, buf), card_number, longopt);
			return 1;
		}
		return (*tlist->handler)(optarg, tlist->file);

	case 'f':
	case 'm':
	case 'a':
	case 'n':
	case 'w':
		if ((tlist = find_token_list(TAB_SIZE(token_stationparam), token_stationparam, opt)) == NULL)
			return 2;
		if (card_number < 0)
		{
			fprintf(stderr, "Radcap card (and station) must be specified for %s\n", longopt);
			return 1;
		}
		if (tlist->type != alsa_cards[card_number].type && tlist->type != radcap_all)
		{
			fprintf(stderr, "Radcap ID %s (ALSA %d) does not handle '%s'\n",
			  text_id(alsa_cards[card_number].hardware_id, buf), card_number, longopt);
			return 1;
		}
		if (station_number < 0)
		{
			fprintf(stderr, "Station must be specified for %s on Radcap %s (ALSA %d)\n",
			  longopt, text_id(alsa_cards[card_number].hardware_id, buf), card_number);
			return 1;
		}
		return (*tlist->handler)(optarg, tlist->file);
	}
	return 2;
}

int
main(int argc, char **argv)
{
	int	opt;
	int	ret;

	myname = argv[0];
#ifdef	FAKE_RADCAP
	srand((int) time(NULL));
#endif
	link_tables();
	discover_radcap();
	if (argc < 2)
	{
		unsigned int	n;

		printf("%u Radcap card%s\n", n_radcap, n_radcap != 1 ? "s" : "");
		for (n = 0; n < n_alsa_card; n++)
			if (alsa_cards[n].type != radcap_none)
				print_config(n);
		return 0;
	}
	opterr = 0;
	ret = 0;
	while ((opt = getopt_long(argc, argv, short_options, long_options, NULL)) != -1)
		if ((opt = do_opt(opt, argv[optind - 1])) > ret)
			ret = opt;
	if (!(params_set & P_PARAM))
		if (params_set & P_STATION)
			print_station(card_number, station_number);
		else if (params_set & P_CARD)
			print_config(card_number);
	return ret;
}

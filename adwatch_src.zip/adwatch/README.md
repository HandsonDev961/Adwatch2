# AdWatch

AdWatch is a tool to help you keep track of your radio ads. Ads must be added to the database and
the system will keep track of the number of times the ad has been played. The system will also keep
a copy of the record to allow you to see what ads have been played and when.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

### Prerequisites

AdWatch requires the following to be installed:

* [Python 3.9](https://www.python.org/downloads/)
* [PostgreSQL 14](https://www.postgresql.org/download/)
* [chromaprint](https://acoustid.org/chromaprint#download)

#### Install the prerequisites on Debian/Ubuntu

```bash
apt-get install python3 python3-venv python3-pip portaudio19-dev libchromaprint1 libchromaprint-tools postgresql postgresql-contrib
```

### Installing

After having Python and PostgreSQL installed and configured, you can install the remaining

```bash
# Create a virtual environment
python3 -m venv venv

# Activate the virtual environment
source venv/bin/activate

# Install the requirements
pip install -r requirements.txt

# Create a database
createdb adwatch

# Run the migrations
python manage.py migrate

# Create a superuser
python manage.py createsuperuser

# Run the server
python manage.py runserver
```

#### Open the admin page
http://127.0.0.1:8000/admin/
